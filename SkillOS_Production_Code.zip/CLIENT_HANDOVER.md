# SkillOS (Alpharive) - Client Handover Document

Welcome to the **SkillOS** repository. This document outlines the technical architecture, environment requirements, and deployment instructions to successfully launch this application into production.

---

## 🏗️ Architecture Overview

SkillOS is a full-stack, AI-powered Communication Training Platform.
- **Frontend:** Next.js (React), styled with CSS modules / Tailwind. Runs on port `3000`.
- **Backend:** FastAPI (Python), utilizing SQLAlchemy, MediaPipe (Computer Vision), and OpenAI (LLM). Runs on port `8000`.
- **Database:** Currently configured for SQLite (for ease of portability). Fully compatible with PostgreSQL.

---

## 🔑 Required API Keys

Before deploying, ensure you have the following API keys ready:
1. **OpenAI API Key (`OPENAI_API_KEY`)**: Required for the conversational AI persona roleplays and the post-session narrative evaluation generation.

---

## 🚀 Deployment Option 1: Docker (Recommended for VPS / AWS / DigitalOcean)

The simplest way to deploy the entire stack is via the provided `docker-compose.yml`.

### Prerequisites
- Docker and Docker Compose installed on your server.

### Steps
1. Transfer the source code to your server.
2. Edit `docker-compose.yml` to insert your `OPENAI_API_KEY`.
3. If deploying to a public domain, change `NEXT_PUBLIC_API_URL` in the `frontend` service to point to your backend's public URL (e.g., `https://api.yourdomain.com`).
4. Run the stack:
   ```bash
   docker-compose up -d --build
   ```
5. The application will be live at `http://<your-server-ip>:3000`.

---

## ☁️ Deployment Option 2: Cloud PaaS (Vercel + Render/Railway)

For a highly scalable, serverless deployment:

### Backend (Render / Railway)
1. Connect your GitHub repository to Render or Railway.
2. Select the `alpharive-backend` folder as the root directory.
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
5. Add Environment Variables:
   - `OPENAI_API_KEY`: Your key
   - `ENVIRONMENT`: `production`
6. Deploy the backend and copy the generated public URL (e.g., `https://alpharive-api.onrender.com`).

### Frontend (Vercel)
1. Connect your GitHub repository to Vercel.
2. Select the `alpharive-frontend` folder as the root directory.
3. Framework Preset: **Next.js**.
4. Add Environment Variables:
   - `NEXT_PUBLIC_API_URL`: Paste the backend URL from the previous step.
5. Deploy.

---

## 📦 Preparing the Codebase for Handover

To send this codebase to your client as a ZIP file, please make sure you **delete** the following folders to significantly reduce the file size and remove unnecessary local configurations:
- `alpharive-backend/venv/` (Local Python environment)
- `alpharive-backend/__pycache__/`
- `alpharive-frontend/node_modules/` (Local Node dependencies)
- `alpharive-frontend/.next/` (Local build cache)

You can run this PowerShell command from the project root to create a clean ZIP:
```powershell
Compress-Archive -Path "alpharive-backend", "alpharive-frontend", "docker-compose.yml", "CLIENT_HANDOVER.md" -DestinationPath "SkillOS_Production_Code.zip"
```

Enjoy your AI Communication Coach!
