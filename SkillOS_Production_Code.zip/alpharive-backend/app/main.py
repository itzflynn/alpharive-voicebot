import logging
import os
os.environ["ANYIO_MAX_THREADS"] = "200"

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from app.config import settings
from app.database import create_tables
from app.routers import auth, scenarios, sessions, analytics
from app.routers import share, custom_scenarios, bot

from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from app.utils.rate_limit import limiter

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="SkillOS API",
    description="AI Communication Training Platform — Skill Operating System",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# ── CORS ───────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Static files (recordings) ───────────────────────────────────────────────────
UPLOADS_DIR = os.path.join(os.path.dirname(__file__), "..", "uploads")
os.makedirs(UPLOADS_DIR, exist_ok=True)

# ── Routers ────────────────────────────────────────────────────────────────────
app.include_router(auth.router)
app.include_router(scenarios.router)
app.include_router(sessions.router)
app.include_router(analytics.router)
app.include_router(share.router)
app.include_router(custom_scenarios.router)
app.include_router(bot.router)


@app.on_event("startup")
async def startup():
    logger.info("SkillOS API v2.0 starting up...")
    create_tables()

    # Seed scenarios on first run
    from app.database import SessionLocal
    from app.services.scenario_seeder import seed_scenarios
    db = SessionLocal()
    try:
        added = seed_scenarios(db)
        if added:
            logger.info(f"Seeded {added} training scenarios")
    finally:
        db.close()

    logger.info("SkillOS API v2.0 ready")


@app.get("/", tags=["Health"])
def root():
    return {"service": "SkillOS API", "version": "2.0.0", "status": "operational"}


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}
