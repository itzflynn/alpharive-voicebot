from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime


class SessionStartRequest(BaseModel):
    scenario_id: str


class SessionStartResponse(BaseModel):
    session_id: str
    status: str
    scenario_title: str
    scenario_briefing: str
    duration_minutes: int
    started_at: datetime


class SessionCompleteRequest(BaseModel):
    transcript: str
    duration_seconds: int
    metadata: Optional[Dict[str, Any]] = {}


class SessionOut(BaseModel):
    id: str
    scenario_id: str
    status: str
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    duration_seconds: Optional[int]
    created_at: datetime

    class Config:
        from_attributes = True


class ImprovementPlan(BaseModel):
    this_week: str
    this_month: str
    long_term: str


class FeedbackOut(BaseModel):
    id: str
    session_id: str
    overall_score: Optional[float]
    confidence_score: Optional[float]
    clarity_score: Optional[float]
    tone_score: Optional[float]
    persuasion_score: Optional[float]
    filler_control_score: Optional[float]
    filler_word_count: Optional[int] = 0
    filler_words: Optional[List[str]] = []
    strengths: Optional[List[str]] = []
    improvements: Optional[List[str]] = []
    detailed_feedback: Optional[str]
    improvement_plan: Optional[Dict] = None
    next_recommended_scenario: Optional[str]
    pacing_wpm: Optional[int] = None
    rephrasing_suggestions: Optional[List[Dict[str, str]]] = None
    eye_contact_score: Optional[float] = None
    smile_score: Optional[float] = None
    pronunciation_score: Optional[float] = None
    pronunciation_feedback: Optional[str] = None
    generated_at: datetime

    class Config:
        from_attributes = True

