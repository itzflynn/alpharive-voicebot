from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class ScenarioCreate(BaseModel):
    title: str
    description: Optional[str] = None
    category: str
    difficulty: str
    skills_targeted: List[str] = []
    duration_minutes: int = 10
    briefing: str
    system_prompt: Optional[str] = None
    thumbnail_url: Optional[str] = None
    is_published: bool = True


class ScenarioUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    difficulty: Optional[str] = None
    skills_targeted: Optional[List[str]] = None
    duration_minutes: Optional[int] = None
    briefing: Optional[str] = None
    system_prompt: Optional[str] = None
    is_published: Optional[bool] = None


class ScenarioOut(BaseModel):
    id: str
    title: str
    description: Optional[str]
    category: str
    difficulty: str
    skills_targeted: List[str]
    duration_minutes: int
    briefing: str
    thumbnail_url: Optional[str]
    is_published: bool
    play_count: int
    created_at: datetime

    class Config:
        from_attributes = True
