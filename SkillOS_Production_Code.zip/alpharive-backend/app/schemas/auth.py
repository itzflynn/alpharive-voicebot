from pydantic import BaseModel, EmailStr
from typing import Optional


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    first_name: str
    last_name: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(BaseModel):
    refresh_token: str


class UserOut(BaseModel):
    id: str
    email: str
    full_name: Optional[str]
    role: str
    org_id: Optional[str]
    avatar_url: Optional[str]
    onboarding_completed: Optional[bool] = False
    primary_goal: Optional[str] = None
    bio: Optional[str] = None
    job_title: Optional[str] = None
    preferences: Optional[dict] = None

    class Config:
        from_attributes = True
