"""Seed 10 initial training scenarios across 4 categories."""
from app.models.scenario import Scenario

SEED_SCENARIOS = [
    # ── Sales ──────────────────────────────────────────────────────────────────
    {
        "title": "Cold Call: Skeptical Gatekeeper",
        "description": "Convince a skeptical receptionist to connect you to the decision-maker.",
        "category": "sales",
        "difficulty": "beginner",
        "skills_targeted": ["confidence", "persuasion"],
        "duration_minutes": 8,
        "briefing": "You are a B2B sales rep calling a mid-size company. The receptionist is guarded and reluctant to transfer calls. Your goal is to professionally handle the objection and get connected to the VP of Operations.",
        "system_prompt": "You are a skeptical corporate receptionist. Be polite but protective of the executive's time. Ask 'What is this regarding?' and only transfer after the caller gives a compelling reason. Stay in character.",
        "thumbnail_url": None,
    },
    {
        "title": "Demo Closing: The Price Objection",
        "description": "Handle a prospect saying 'Your pricing is too high' after a demo.",
        "category": "sales",
        "difficulty": "intermediate",
        "skills_targeted": ["persuasion", "clarity", "confidence"],
        "duration_minutes": 10,
        "briefing": "You just finished a product demo and the prospect says the price is 40% above their budget. You need to reframe value, explore flexibility, and move toward a signed agreement.",
        "system_prompt": "You are a cost-conscious VP of Finance evaluating a SaaS product. You liked the demo but are firm on budget constraints. Ask about ROI, competitors, and payment terms. Only soften if the rep clearly articulates value.",
        "thumbnail_url": None,
    },
    # ── Customer Service ────────────────────────────────────────────────────────
    {
        "title": "Angry Customer: Billing Dispute",
        "description": "De-escalate an angry customer disputing a double charge.",
        "category": "customer_service",
        "difficulty": "beginner",
        "skills_targeted": ["tone", "clarity", "confidence"],
        "duration_minutes": 8,
        "briefing": "A customer calls furious about being charged twice for their subscription. They are threatening to cancel and post a negative review. Your goal is to de-escalate, solve the issue, and retain the customer.",
        "system_prompt": "You are an angry customer who was charged twice. You are frustrated and vocal but will calm down if the agent listens, empathizes genuinely, and provides a clear resolution. Start hostile, soften only if treated with respect and competence.",
        "thumbnail_url": None,
    },
    {
        "title": "Escalation Management: Product Failure",
        "description": "Handle a VIP enterprise client threatening to cancel after a product outage.",
        "category": "customer_service",
        "difficulty": "advanced",
        "skills_targeted": ["tone", "persuasion", "confidence"],
        "duration_minutes": 12,
        "briefing": "A key enterprise account experienced a 4-hour outage causing major business disruption. The account manager calls demanding answers, an SLA credit, and guarantees it won't happen again. You must retain the account.",
        "system_prompt": "You are an enterprise account manager who is professionally angry. You are data-driven. Demand a root cause analysis, SLA credit, and a written incident report. Only de-escalate if the rep takes ownership and offers concrete commitments.",
        "thumbnail_url": None,
    },
    # ── Leadership ──────────────────────────────────────────────────────────────
    {
        "title": "Difficult Feedback: Underperforming Team Member",
        "description": "Deliver constructive performance feedback to a defensive employee.",
        "category": "leadership",
        "difficulty": "intermediate",
        "skills_targeted": ["tone", "clarity", "confidence"],
        "duration_minutes": 10,
        "briefing": "One of your team members has missed three deadlines in the past month. They are talented but seem disengaged. You need to have a direct, honest conversation about performance while keeping them motivated.",
        "system_prompt": "You are a mid-level employee who feels undervalued and slightly defensive. You have personal reasons for the delays but haven't shared them. Open up only if the manager creates a psychologically safe space. Push back on vague criticism.",
        "thumbnail_url": None,
    },
    {
        "title": "Executive Presentation: Board Strategy Update",
        "description": "Present a strategic pivot to a skeptical board of directors.",
        "category": "leadership",
        "difficulty": "advanced",
        "skills_targeted": ["confidence", "persuasion", "clarity"],
        "duration_minutes": 15,
        "briefing": "You are presenting a major strategic pivot to the board — shifting from a product-led to a sales-led growth model. Two board members are skeptical. You have 10 minutes to make your case with data and conviction.",
        "system_prompt": "You are a skeptical board member with a background in finance. Ask hard questions about CAC, payback period, and risk mitigation. Challenge assumptions but remain professional. Be convinced only by clear data and confident delivery.",
        "thumbnail_url": None,
    },
    # ── Interviews ──────────────────────────────────────────────────────────────
    {
        "title": "Behavioral Interview: Tell Me About a Failure",
        "description": "Navigate the 'greatest failure' interview question with authenticity.",
        "category": "interviews",
        "difficulty": "beginner",
        "skills_targeted": ["confidence", "clarity", "tone"],
        "duration_minutes": 8,
        "briefing": "You are interviewing for a Senior Product Manager role at a top tech company. The interviewer asks: 'Tell me about your biggest professional failure and what you learned from it.' Structure your answer with the STAR method.",
        "system_prompt": "You are a senior product manager interviewer. Ask follow-up questions probing the candidate's self-awareness, accountability, and growth mindset. Push back gently if the failure seems too minor or the lesson too generic.",
        "thumbnail_url": None,
    },
    {
        "title": "Technical Interview: System Design",
        "description": "Explain the design of a URL shortener to a staff engineer.",
        "category": "interviews",
        "difficulty": "advanced",
        "skills_targeted": ["clarity", "confidence", "persuasion"],
        "duration_minutes": 15,
        "briefing": "You are interviewing for a Senior Software Engineer role. The interviewer asks you to design a URL shortening service (like bit.ly) handling 100M URLs. Walk through scalability, database design, and trade-offs.",
        "system_prompt": "You are a staff engineer conducting a system design interview. Ask clarifying questions, probe for scalability thinking (sharding, caching, CDN), and challenge architectural choices. Be impressed by structured thinking and humbled by vague hand-waving.",
        "thumbnail_url": None,
    },
    # ── Negotiation ─────────────────────────────────────────────────────────────
    {
        "title": "Salary Negotiation: Competing Offer",
        "description": "Negotiate a higher salary offer using a competing offer as leverage.",
        "category": "negotiation",
        "difficulty": "intermediate",
        "skills_targeted": ["confidence", "persuasion", "clarity"],
        "duration_minutes": 10,
        "briefing": "You have received a job offer at $120K but you have a competing offer at $140K from a company you prefer less. You want to negotiate to at least $135K plus equity without coming across as purely money-motivated.",
        "system_prompt": "You are an HR Director handling the offer. You like the candidate but have budget constraints. You can go up to $130K and add a signing bonus. Be firm but reasonable. Be swayed by market data and clear value articulation, not just competing offer mention.",
        "thumbnail_url": None,
    },
    {
        "title": "Vendor Negotiation: Renewal Pricing",
        "description": "Negotiate a software vendor renewal down by 20% without losing the relationship.",
        "category": "negotiation",
        "difficulty": "intermediate",
        "skills_targeted": ["persuasion", "confidence", "tone"],
        "duration_minutes": 10,
        "briefing": "Your $80K/year SaaS contract is up for renewal. The vendor wants to increase pricing by 15%. Your CFO has mandated a 20% reduction. You must negotiate a win-win outcome while keeping the vendor relationship intact.",
        "system_prompt": "You are a vendor account executive who has been told to protect margin. You can offer a 10% discount for a 2-year commit or a 5% discount with a case study. Push back professionally on deeper discounts unless the buyer offers multi-year or a reference.",
        "thumbnail_url": None,
    },
]


def seed_scenarios(db) -> int:
    """Seed initial scenarios if none exist. Returns count added."""
    existing = db.query(Scenario).count()
    if existing > 0:
        return 0

    for data in SEED_SCENARIOS:
        scenario = Scenario(**data)
        db.add(scenario)

    db.commit()
    return len(SEED_SCENARIOS)
