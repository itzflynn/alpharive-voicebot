"""
Session Orchestration Service
Manages the session lifecycle and triggers AI evaluation on completion.
"""
from datetime import datetime
from sqlalchemy.orm import Session as DBSession
from app.models.session import TrainingSession
from app.models.scenario import Scenario
from app.models.feedback import Feedback
from app.models.skill_score import SkillScore
from app.models.user import User
from app.schemas.session import SessionStartRequest, SessionStartResponse, SessionCompleteRequest
from app.services.evaluation_service import generate_evaluation
from fastapi import HTTPException
import logging

logger = logging.getLogger(__name__)


def start_session(req: SessionStartRequest, user: User, db: DBSession) -> SessionStartResponse:
    scenario = db.query(Scenario).filter(Scenario.id == req.scenario_id, Scenario.is_published == True).first()
    if not scenario:
        raise HTTPException(status_code=404, detail="Scenario not found")

    # Increment play count
    scenario.play_count = (scenario.play_count or 0) + 1

    session = TrainingSession(
        user_id=user.id,
        scenario_id=scenario.id,
        org_id=user.org_id,
        status="active",
        started_at=datetime.utcnow(),
    )
    db.add(session)
    db.commit()
    db.refresh(session)

    return SessionStartResponse(
        session_id=session.id,
        status=session.status,
        scenario_title=scenario.title,
        scenario_briefing=scenario.briefing,
        duration_minutes=scenario.duration_minutes,
        started_at=session.started_at,
    )


async def complete_session(
    session_id: str,
    req: SessionCompleteRequest,
    user: User,
    db: DBSession,
) -> dict:
    session = db.query(TrainingSession).filter(
        TrainingSession.id == session_id,
        TrainingSession.user_id == user.id,
    ).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.status == "completed":
        raise HTTPException(status_code=400, detail="Session already completed")

    scenario = db.query(Scenario).filter(Scenario.id == session.scenario_id).first()

    # Update session
    session.status = "completed"
    session.completed_at = datetime.utcnow()
    session.duration_seconds = req.duration_seconds
    session.transcript = req.transcript
    session.raw_metadata = req.metadata
    db.commit()

    # Generate video analysis
    import os
    from fastapi.concurrency import run_in_threadpool
    from app.services.video_analysis import analyze_video
    
    RECORDINGS_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "uploads", "recordings")
    final_video_path = os.path.join(RECORDINGS_DIR, session.id, "final.webm")
    
    cv_metrics = {"eye_contact_score": None, "smile_score": None}
    if os.path.exists(final_video_path):
        try:
            cv_metrics = await run_in_threadpool(analyze_video, final_video_path)
        except Exception as e:
            logger.error(f"Video analysis failed: {e}")

    # Generate AI evaluation (async)
    try:
        eval_result = await generate_evaluation(
            transcript=req.transcript,
            scenario_title=scenario.title,
            scenario_category=scenario.category or "general",
            skills_targeted=scenario.skills_targeted or [],
            difficulty=scenario.difficulty or "intermediate",
            duration_minutes=scenario.duration_minutes,
            duration_seconds=req.duration_seconds,
        )

        dim = eval_result.get("dimension_scores", {})
        feedback = Feedback(
            session_id=session.id,
            user_id=user.id,
            overall_score=eval_result.get("overall_score"),
            confidence_score=dim.get("confidence"),
            clarity_score=dim.get("clarity"),
            tone_score=dim.get("tone"),
            persuasion_score=dim.get("persuasion"),
            filler_control_score=dim.get("filler_control"),
            filler_word_count=eval_result.get("filler_word_count", 0),
            filler_words=eval_result.get("filler_words_detected", []),
            strengths=eval_result.get("strengths", []),
            improvements=eval_result.get("areas_for_improvement", []),
            detailed_feedback=eval_result.get("detailed_feedback"),
            improvement_plan=eval_result.get("improvement_plan"),
            next_recommended_scenario=eval_result.get("next_recommended_scenario"),
            pacing_wpm=req.metadata.get("pacing_wpm") if req.metadata else None,
            rephrasing_suggestions=eval_result.get("rephrasing_suggestions", []),
            vocabulary_analysis=eval_result.get("vocabulary_analysis"),
            eye_contact_score=cv_metrics.get("eye_contact_score"),
            smile_score=cv_metrics.get("smile_score"),
            pronunciation_score=eval_result.get("pronunciation_score"),
            pronunciation_feedback=eval_result.get("pronunciation_feedback"),
            llm_model_used=eval_result.get("_llm_model", "rule-based"),
        )
        db.add(feedback)

        # Store skill scores for trend tracking
        skill_map = {
            "confidence": dim.get("confidence"),
            "clarity": dim.get("clarity"),
            "tone": dim.get("tone"),
            "persuasion": dim.get("persuasion"),
            "filler_control": dim.get("filler_control"),
        }
        for skill, score in skill_map.items():
            if score is not None:
                db.add(SkillScore(user_id=user.id, skill=skill, score=score, session_id=session.id))

        db.commit()
        db.refresh(feedback)

        return {"session_id": session.id, "status": "evaluated", "feedback_id": feedback.id}

    except Exception as e:
        logger.error(f"Evaluation failed for session {session_id}: {e}")
        return {"session_id": session.id, "status": "completed", "feedback_id": None}
