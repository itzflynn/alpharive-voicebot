import cv2
import mediapipe as mp
import logging

logger = logging.getLogger(__name__)
mp_face_mesh = mp.solutions.face_mesh

def analyze_video(video_path: str):
    logger.info(f"Starting video analysis for {video_path}")
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        logger.error(f"Cannot open video {video_path}")
        return {"eye_contact_score": None, "smile_score": None}

    total_frames = 0
    eye_contact_frames = 0
    smile_frames = 0

    with mp_face_mesh.FaceMesh(
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    ) as face_mesh:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            total_frames += 1
            if total_frames % 5 != 0:  # Process every 5th frame to speed up
                continue

            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = face_mesh.process(rgb_frame)

            if results.multi_face_landmarks:
                landmarks = results.multi_face_landmarks[0].landmark
                
                # Check Eye Contact (Head Pose Proxy)
                nose = landmarks[1]
                left_ear = landmarks[234]
                right_ear = landmarks[454]
                
                ear_dist = abs(left_ear.x - right_ear.x)
                nose_dist_left = abs(nose.x - left_ear.x)
                nose_dist_right = abs(right_ear.x - nose.x)
                
                if ear_dist > 0:
                    ratio = min(nose_dist_left, nose_dist_right) / ear_dist
                    if ratio > 0.35: # fairly centered
                        eye_contact_frames += 1
                
                # Check Smile (Mouth Aspect Ratio)
                top_lip = landmarks[13]
                bottom_lip = landmarks[14]
                left_lip = landmarks[78]
                right_lip = landmarks[308]
                
                mouth_height = abs(top_lip.y - bottom_lip.y)
                mouth_width = abs(left_lip.x - right_lip.x)
                
                if mouth_width > 0:
                    mar = mouth_height / mouth_width
                    if mar > 0.35: # Threshold for smile
                        smile_frames += 1

    cap.release()
    
    processed_frames = total_frames // 5
    if processed_frames == 0:
        return {"eye_contact_score": None, "smile_score": None}
        
    eye_contact_score = min(100.0, (eye_contact_frames / processed_frames) * 100 * 1.2)
    smile_score = min(100.0, (smile_frames / processed_frames) * 100 * 2.0) # boost smile score

    logger.info(f"Video analysis complete. Eye: {eye_contact_score:.1f}, Smile: {smile_score:.1f}")
    return {"eye_contact_score": round(eye_contact_score, 1), "smile_score": round(smile_score, 1)}
