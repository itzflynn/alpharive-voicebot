"""
SkillOS AI Evaluation Engine — Core IP Layer
All prompts, scoring logic, and feedback generation are proprietary.
LLM provider is abstracted and swappable.
"""
import json
import re
import logging
from typing import Optional
from app.config import settings

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# PROPRIETARY EVALUATION PROMPTS
# ──────────────────────────────────────────────────────────────────────────────

EVALUATION_SYSTEM_PROMPT = """
You are SkillOS's Communication Intelligence Engine — a proprietary AI evaluator.
You analyze transcripts of communication training sessions and generate structured, 
actionable feedback across 5 core skill dimensions.

SKILL DIMENSIONS:
1. CONFIDENCE (0-100): Assertiveness, decisiveness, absence of hedging language
2. CLARITY (0-100): Structure, conciseness, absence of ambiguity or tangents
3. TONE (0-100): Empathy, professionalism, emotional intelligence, warmth
4. PERSUASION (0-100): Use of evidence, storytelling, compelling call-to-action
5. FILLER_CONTROL (0-100): Penalize frequent "um", "uh", "like", "you know", "so"
   - 0 fillers = 100, 1-3 = 85, 4-7 = 70, 8-15 = 55, 16+ = 30

OVERALL SCORE = weighted average:
  Confidence×0.25 + Clarity×0.25 + Tone×0.20 + Persuasion×0.20 + FillerControl×0.10

RULES:
- Be honest but constructive. Score accurately — do not inflate scores.
- Base all feedback strictly on what is observable in the transcript.
- Never fabricate or assume content not present in the transcript.
- Keep strengths and improvements concise and specific (1-2 sentences each).
- The improvement plan must be concrete and actionable.

OUTPUT: Return ONLY valid JSON matching this exact schema (no markdown, no extra text):
{
  "overall_score": <float 0-100>,
  "dimension_scores": {
    "confidence": <float 0-100>,
    "clarity": <float 0-100>,
    "tone": <float 0-100>,
    "persuasion": <float 0-100>,
    "filler_control": <float 0-100>
  },
  "filler_words_detected": ["um", "uh", ...],
  "filler_word_count": <int>,
  "strengths": ["<specific strength 1>", "<specific strength 2>", "<specific strength 3>"],
  "areas_for_improvement": ["<specific area 1>", "<specific area 2>", "<specific area 3>"],
  "detailed_feedback": "<2-3 paragraph narrative assessment>",
  "pronunciation_score": <float 0-100>,
  "pronunciation_feedback": "<1-2 sentences on clarity of articulation, phonetic structure, and enunciation>",
  "improvement_plan": {
    "this_week": "<one concrete daily practice action>",
    "this_month": "<one structured improvement goal>",
    "long_term": "<one career-level development direction>"
  },
  "next_recommended_scenario": "<category or scenario title best matching user's weakness>"
}
"""

EVALUATION_USER_TEMPLATE = """
SCENARIO CONTEXT:
Title: {scenario_title}
Category: {scenario_category}
Skills Targeted: {skills_targeted}
Difficulty: {difficulty}
Expected Duration: {duration_minutes} minutes

SESSION METADATA:
Actual Duration: {duration_seconds} seconds
Detected Filler Count (pre-analysis): {filler_count}

TRANSCRIPT:
---
{transcript}
---

Analyze this transcript and return the evaluation JSON.
"""

FILLER_WORDS = [
    "um", "uh", "uhh", "like", "you know", "so", "basically", "literally",
    "actually", "right", "okay so", "kind of", "sort of", "i mean", "well",
]

# ──────────────────────────────────────────────────────────────────────────────
# VOCABULARY ANALYSIS
# ──────────────────────────────────────────────────────────────────────────────

POWER_WORDS = [
    "leverage", "drive", "optimize", "align", "innovate", "deliver", "impact",
    "scalable", "roi", "strategic", "execute", "prioritize", "accelerate",
    "transform", "empower", "streamline", "measurable", "actionable", "collaborate", "vision",
]

WEAK_WORDS = [
    "maybe", "kind of", "sort of", "i think", "i guess", "hopefully",
    "try to", "might", "basically", "literally", "actually", "you know", "right", "like",
]


def compute_vocabulary_analysis(transcript: str) -> dict:
    """
    Analyzes vocabulary richness, power word usage, and weak/hedge words.
    Returns a dict with metrics and a composite vocabulary_score.
    """
    # Extract only trainee lines for analysis
    trainee_lines = []
    for line in transcript.split("\n"):
        if line.startswith("Trainee:"):
            trainee_lines.append(line.replace("Trainee:", "").strip())
        elif not line.startswith("AI:") and line.strip():
            trainee_lines.append(line.strip())

    analysis_text = " ".join(trainee_lines) if trainee_lines else transcript
    text_lower = analysis_text.lower()
    words = re.findall(r"\b[a-z']+\b", text_lower)
    total_words = len(words)

    if total_words == 0:
        return {
            "power_words_used": [],
            "power_word_count": 0,
            "weak_words_used": [],
            "weak_word_count": 0,
            "vocabulary_diversity": 0,
            "avg_sentence_length": 0,
            "question_ratio": 0,
            "vocabulary_score": 0,
        }

    # Power words
    power_found = [pw for pw in POWER_WORDS if re.search(r"\b" + re.escape(pw) + r"\b", text_lower)]
    power_count = sum(len(re.findall(r"\b" + re.escape(pw) + r"\b", text_lower)) for pw in power_found)

    # Weak words (multi-word phrases supported)
    weak_found = [ww for ww in WEAK_WORDS if ww in text_lower]
    weak_count = sum(text_lower.count(ww) for ww in weak_found)

    # Vocabulary diversity: unique / total words
    unique_words = len(set(words))
    diversity = round(unique_words / total_words * 100, 1)

    # Average sentence length
    sentences = [s.strip() for s in re.split(r"[.!?]", analysis_text) if len(s.strip()) > 3]
    sentence_count = max(len(sentences), 1)
    avg_sentence_len = round(total_words / sentence_count, 1)

    # Question ratio
    question_sentences = [s for s in sentences if "?" in s or
                          any(q in s.lower() for q in ["how", "why", "what", "when", "where", "who", "would", "could", "can"])]
    question_ratio = round(len(question_sentences) / sentence_count * 100, 1)

    # Composite vocabulary score (0-100)
    power_boost = min(power_count * 5, 25)          # max 25 pts from power words
    weak_penalty = min(weak_count * 4, 30)           # max -30 pts from weak words
    diversity_score = min(diversity, 60)              # cap diversity contribution
    vocab_score = max(0, min(100, 40 + power_boost - weak_penalty + diversity_score * 0.5))

    return {
        "power_words_used": power_found[:10],
        "power_word_count": power_count,
        "weak_words_used": weak_found[:10],
        "weak_word_count": weak_count,
        "vocabulary_diversity": diversity,
        "avg_sentence_length": avg_sentence_len,
        "question_ratio": question_ratio,
        "vocabulary_score": round(vocab_score),
    }


# ──────────────────────────────────────────────────────────────────────────────
# FILLER DETECTION
# ──────────────────────────────────────────────────────────────────────────────

def _count_fillers(transcript: str) -> tuple[int, list[str]]:
    text = transcript.lower()
    found = []
    count = 0
    for fw in FILLER_WORDS:
        pattern = r"\b" + re.escape(fw) + r"\b"
        matches = re.findall(pattern, text)
        if matches:
            found.append(fw)
            count += len(matches)
    return count, found


def _fallback_score(transcript: str) -> dict:
    """Advanced heuristic-based scoring when LLM is unavailable."""
    text = transcript.lower()
    
    # Extract only the trainee's words if transcript is formatted
    trainee_lines = []
    for line in transcript.split("\n"):
        if line.startswith("Trainee:"):
            trainee_lines.append(line.replace("Trainee:", "").strip().lower())
        elif not line.startswith("AI:") and line.strip():
            trainee_lines.append(line.strip().lower())
            
    analysis_text = " ".join(trainee_lines) if trainee_lines else text
    words = analysis_text.split()
    word_count = len(words)
    
    if word_count < 10:
        vocab_analysis = compute_vocabulary_analysis(transcript)
        return {
            "overall_score": 30,
            "dimension_scores": {"confidence": 30, "clarity": 30, "tone": 30, "persuasion": 30, "filler_control": 100},
            "filler_words_detected": [],
            "filler_word_count": 0,
            "strengths": ["You successfully initiated the session."],
            "areas_for_improvement": ["Your response was too brief to be fully evaluated.", "Provide more detail and elaboration."],
            "detailed_feedback": "Your transcript was extremely short. In a real scenario, you need to provide much more substance and detail to drive the conversation forward.",
            "pronunciation_score": 85.0,
            "pronunciation_feedback": "Speech was generally clear, but too brief for deep analysis.",
            "improvement_plan": {
                "this_week": "Practice speaking for at least 60 seconds without stopping.",
                "this_month": "Focus on elaborating your points using the 'What, Why, How' framework.",
                "long_term": "Build stamina for longer, substantive professional conversations."
            },
            "rephrasing_suggestions": [],
            "vocabulary_analysis": vocab_analysis,
            "next_recommended_scenario": "basics"
        }

    filler_count, filler_words = _count_fillers(analysis_text)
    
    hedging_words = ["maybe", "perhaps", "i think", "i guess", "probably", "might", "could be", "sort of", "kind of"]
    strong_words = ["will", "guarantee", "ensure", "confident", "definitely", "absolutely", "must", "always", "can"]
    collab_words = ["we", "together", "understand", "appreciate", "help", "value", "partner", "agree", "support"]
    reasoning_words = ["because", "since", "result", "impact", "therefore", "benefit", "leads to", "meaning"]
    
    hedge_count = sum(analysis_text.count(w) for w in hedging_words)
    strong_count = sum(analysis_text.count(w) for w in strong_words)
    collab_count = sum(analysis_text.count(w) for w in collab_words)
    reason_count = sum(analysis_text.count(w) for w in reasoning_words)
    
    confidence = 70 + (strong_count * 6) - (hedge_count * 8) - (filler_count * 2)
    tone = 65 + (collab_count * 8)
    persuasion = 60 + (reason_count * 10)
    
    sentences = [s.strip() for s in re.split(r'[.!?]', analysis_text) if s.strip()]
    avg_sentence_len = word_count / max(len(sentences), 1)
    
    clarity = 85
    if avg_sentence_len > 25:
        clarity -= (avg_sentence_len - 25) * 2
    elif avg_sentence_len < 6:
        clarity -= 15
        
    filler_score = max(30, 100 - filler_count * 8)
    
    confidence = max(30, min(100, confidence))
    tone = max(30, min(100, tone))
    persuasion = max(30, min(100, persuasion))
    clarity = max(30, min(100, clarity))
    
    overall = round(confidence * 0.25 + clarity * 0.25 + tone * 0.20 + persuasion * 0.20 + filler_score * 0.10, 2)
    
    strengths = []
    improvements = []
    
    if confidence >= 80: strengths.append("Used highly definitive and assertive language.")
    else: improvements.append("Reduce hedging language (e.g., 'maybe', 'I think') to sound more authoritative.")
        
    if clarity >= 80: strengths.append("Maintained excellent sentence structure and conciseness.")
    else: improvements.append("Your sentences were quite long. Break complex thoughts into shorter statements.")
        
    if tone >= 80: strengths.append("Demonstrated high empathy through collaborative vocabulary.")
    else: improvements.append("Incorporate more collaborative words ('we', 'understand') to build rapport.")
        
    if persuasion >= 80: strengths.append("Built a strong logical case using clear reasoning markers.")
    else: improvements.append("Use stronger reasoning markers ('because', 'therefore') to connect points.")
        
    if filler_score >= 80: strengths.append("Excellent control of filler words.")
    else: improvements.append(f"You used {filler_count} filler words. Practice pausing silently instead.")

    if len(strengths) == 0: strengths.append("Maintained engagement throughout the scenario.")
    if len(improvements) == 0: improvements.append("Continue practicing to maintain this high level of performance.")
    
    narrative = f"Your overall communication effectiveness scored {overall}/100. "
    if filler_count > 4 and filler_words:
        narrative += f"The most noticeable area for immediate improvement is filler word control, as words like '{filler_words[0]}' detracted from your delivery. "
    if hedge_count >= 2:
        narrative += "You also relied on hedging phrases which reduced your perceived confidence. "
    elif strong_count >= 2:
        narrative += "You projected excellent confidence through strong, definitive vocabulary. "
        
    if reason_count < 2:
        narrative += "To make your arguments more compelling, explicitly state the 'why' behind your points."
    else:
        narrative += "Your points were well-supported with logical reasoning."

    # Generate AI Rephrasing Suggestions
    rephrasing_suggestions = []
    for sentence in sentences:
        s_lower = sentence.lower()
        if any(w in s_lower for w in hedging_words):
            improved = sentence
            for w in hedging_words:
                improved = re.compile(re.escape(w) + r'\b', re.IGNORECASE).sub("", improved).strip()
            if improved and improved != sentence:
                rephrasing_suggestions.append({
                    "original": sentence.capitalize() + ".",
                    "improved": improved.capitalize() + " (Removed hedging words for more confidence)."
                })
                if len(rephrasing_suggestions) >= 2: break
                
    if not rephrasing_suggestions and sentences:
        rephrasing_suggestions.append({
            "original": sentences[0].capitalize() + ".",
            "improved": sentences[0].capitalize() + " (Good start — try adding a 'because' statement for impact)."
        })

    vocab_analysis = compute_vocabulary_analysis(transcript)

    return {
        "overall_score": overall,
        "dimension_scores": {
            "confidence": round(confidence),
            "clarity": round(clarity),
            "tone": round(tone),
            "persuasion": round(persuasion),
            "filler_control": round(filler_score),
        },
        "filler_words_detected": filler_words,
        "filler_word_count": filler_count,
        "strengths": strengths[:3],
        "areas_for_improvement": improvements[:3],
        "detailed_feedback": narrative,
        "pronunciation_score": 85.0,
        "pronunciation_feedback": "Your articulation was generally clear. Continue to focus on enunciating complex vocabulary clearly.",
        "rephrasing_suggestions": rephrasing_suggestions,
        "vocabulary_analysis": vocab_analysis,
        "improvement_plan": {
            "this_week": "Record a 2-minute pitch and focus entirely on eliminating hedging words.",
            "this_month": "Practice the PAUSE framework: take a 1-second silent breath before answering questions.",
            "long_term": "Develop a personal lexicon of strong action verbs and transition phrases."
        },
        "next_recommended_scenario": "Advanced Negotiation" if overall > 75 else "Foundational Pitch"
    }


async def generate_evaluation(
    transcript: str,
    scenario_title: str,
    scenario_category: str,
    skills_targeted: list,
    difficulty: str,
    duration_minutes: int,
    duration_seconds: int,
) -> dict:
    """Generate AI evaluation. Falls back to rule-based scoring if LLM unavailable."""
    filler_count, _ = _count_fillers(transcript)
    vocab_analysis = compute_vocabulary_analysis(transcript)

    if not settings.OPENAI_API_KEY or settings.OPENAI_API_KEY.startswith("sk-your"):
        logger.warning("No valid OpenAI key — using rule-based evaluation fallback")
        result = _fallback_score(transcript)
        result["vocabulary_analysis"] = vocab_analysis
        return result

    try:
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

        user_prompt = EVALUATION_USER_TEMPLATE.format(
            scenario_title=scenario_title,
            scenario_category=scenario_category,
            skills_targeted=", ".join(skills_targeted),
            difficulty=difficulty,
            duration_minutes=duration_minutes,
            duration_seconds=duration_seconds,
            filler_count=filler_count,
            transcript=transcript[:8000],   # guard against token limits
        )

        response = await client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": EVALUATION_SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.3,
            response_format={"type": "json_object"},
        )

        raw = response.choices[0].message.content
        result = json.loads(raw)
        result["_llm_model"] = "gpt-4o"
        result["vocabulary_analysis"] = vocab_analysis   # always add vocab analysis
        return result

    except Exception as e:
        logger.error(f"LLM evaluation failed: {e} — falling back to rule-based scoring")
        result = _fallback_score(transcript)
        result["vocabulary_analysis"] = vocab_analysis
        return result
