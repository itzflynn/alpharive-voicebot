import re
import uuid
from datetime import datetime
from sqlalchemy.orm import Session
from app.models.user import User
from app.models.organization import Organization
from app.utils.security import hash_password, verify_password
from app.utils.jwt import create_access_token, create_refresh_token, decode_token
from app.schemas.auth import RegisterRequest, LoginRequest, TokenResponse
from fastapi import HTTPException, status, BackgroundTasks
from app.database import SessionLocal


def _make_slug(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return f"{slug}-{str(uuid.uuid4())[:8]}"


def register_user(req: RegisterRequest, db: Session) -> TokenResponse:
    if db.query(User).filter(User.email == req.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    org_name = f"{req.first_name} {req.last_name}'s Workspace"
    org = Organization(name=org_name, slug=_make_slug(org_name))
    db.add(org)
    db.flush()

    user = User(
        email=req.email,
        password_hash=hash_password(req.password),
        full_name=f"{req.first_name} {req.last_name}",
        org_id=org.id,
        role="admin",   # first user in org is admin
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    return _issue_tokens(user)


def _update_last_login(user_id: str):
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if user:
            user.last_login = datetime.utcnow()
            db.commit()
    finally:
        db.close()


def login_user(req: LoginRequest, db: Session, bg_tasks: BackgroundTasks) -> TokenResponse:
    user = db.query(User).filter(User.email == req.email).first()
    if not user or not verify_password(req.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Account disabled")

    bg_tasks.add_task(_update_last_login, user.id)

    return _issue_tokens(user)


def refresh_tokens(refresh_token: str, db: Session) -> TokenResponse:
    payload = decode_token(refresh_token)
    if not payload or payload.get("type") != "refresh":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid refresh token")

    user = db.query(User).filter(User.id == payload.get("sub")).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")

    return _issue_tokens(user)


def _issue_tokens(user: User) -> TokenResponse:
    data = {"sub": user.id, "email": user.email, "role": user.role, "org_id": user.org_id}
    return TokenResponse(
        access_token=create_access_token(data),
        refresh_token=create_refresh_token(data),
    )
