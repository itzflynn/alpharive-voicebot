import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class MeetingBot(Base):
    __tablename__ = "meeting_bots"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey("users.id"))
    meeting_url = Column(String)
    platform = Column(String)
    status = Column(String) # deploying, joined, recording, completed, failed
    bot_name = Column(String, default="SkillOS Notetaker")
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")
