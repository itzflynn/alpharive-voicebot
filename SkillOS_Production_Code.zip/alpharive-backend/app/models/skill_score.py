import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, ForeignKey, Float
from sqlalchemy.orm import relationship
from app.database import Base


class SkillScore(Base):
    __tablename__ = "skill_scores"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    skill = Column(String(100), nullable=False)   # confidence, clarity, tone, persuasion, filler_control
    score = Column(Float, nullable=False)
    session_id = Column(String, ForeignKey("sessions.id"), nullable=True)
    recorded_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="skill_scores")
