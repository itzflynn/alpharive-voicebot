import uuid
from datetime import datetime
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Integer, Text, JSON
from sqlalchemy.orm import relationship
from app.database import Base


class Scenario(Base):
    __tablename__ = "scenarios"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    org_id = Column(String, ForeignKey("organizations.id"), nullable=True)   # NULL = global
    title = Column(String(255), nullable=False)
    description = Column(Text)
    category = Column(String(100))        # sales, leadership, interviews, customer_service
    difficulty = Column(String(50))       # beginner, intermediate, advanced
    skills_targeted = Column(JSON)        # ["confidence", "clarity", "persuasion"]
    duration_minutes = Column(Integer, default=10)
    briefing = Column(Text, nullable=False)
    system_prompt = Column(Text)          # AI persona instructions
    thumbnail_url = Column(String)
    is_published = Column(Boolean, default=True)
    play_count = Column(Integer, default=0)
    created_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Phase 2: Custom scenario builder
    is_custom = Column(Boolean, default=False)
    persona_name = Column(String(255), nullable=True)   # e.g., "Alex"
    persona_role = Column(String(255), nullable=True)   # e.g., "CFO at TechCorp"

    organization = relationship("Organization", back_populates="scenarios")
    sessions = relationship("TrainingSession", back_populates="scenario")
