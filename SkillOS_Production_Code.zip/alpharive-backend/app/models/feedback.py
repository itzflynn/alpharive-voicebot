import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, Float, Text, JSON
from sqlalchemy.orm import relationship
from app.database import Base


class Feedback(Base):
    __tablename__ = "feedback"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id = Column(String, ForeignKey("sessions.id", ondelete="CASCADE"), unique=True)
    user_id = Column(String, ForeignKey("users.id"))
    overall_score = Column(Float)
    confidence_score = Column(Float)
    clarity_score = Column(Float)
    tone_score = Column(Float)
    persuasion_score = Column(Float)
    filler_control_score = Column(Float)
    filler_word_count = Column(Integer, default=0)
    filler_words = Column(JSON)           # ["um", "uh", ...]
    strengths = Column(JSON)              # list of strings
    improvements = Column(JSON)           # list of strings
    detailed_feedback = Column(Text)
    improvement_plan = Column(JSON)       # {this_week, this_month, long_term}
    next_recommended_scenario = Column(String)
    pacing_wpm = Column(Integer, nullable=True)
    rephrasing_suggestions = Column(JSON, nullable=True)
    eye_contact_score = Column(Float, nullable=True)
    smile_score = Column(Float, nullable=True)
    pronunciation_score = Column(Float, nullable=True)
    pronunciation_feedback = Column(Text, nullable=True)

    # Phase 2: Vocabulary analysis
    vocabulary_analysis = Column(JSON, nullable=True)  # { power_words_used, weak_words_used, ... }

    llm_model_used = Column(String(100))
    generated_at = Column(DateTime, default=datetime.utcnow)

    session = relationship("TrainingSession", back_populates="feedback")
    user = relationship("User", back_populates="feedback")
