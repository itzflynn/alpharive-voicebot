import uuid
from datetime import datetime
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Integer, Text, JSON
from sqlalchemy.orm import relationship
from app.database import Base


class TrainingSession(Base):
    __tablename__ = "sessions"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    scenario_id = Column(String, ForeignKey("scenarios.id"), nullable=False)
    org_id = Column(String, ForeignKey("organizations.id"), nullable=True)
    status = Column(String(50), default="pending")   # pending, active, completed, failed
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    duration_seconds = Column(Integer, nullable=True)
    transcript = Column(Text, nullable=True)
    raw_metadata = Column(JSON, nullable=True)       # filler_count, pauses, interruptions
    external_session_ref = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Phase 2: webcam recording
    recording_url = Column(String, nullable=True)

    # Phase 2: session sharing
    share_token = Column(String, nullable=True, unique=True)

    user = relationship("User", back_populates="sessions")
    scenario = relationship("Scenario", back_populates="sessions")
    feedback = relationship("Feedback", back_populates="session", uselist=False)
