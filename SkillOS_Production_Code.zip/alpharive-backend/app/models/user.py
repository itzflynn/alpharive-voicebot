import uuid
from datetime import datetime
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from app.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    org_id = Column(String, ForeignKey("organizations.id", ondelete="CASCADE"), nullable=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255))
    role = Column(String(50), default="user")   # admin, manager, user
    avatar_url = Column(String)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)

    # Onboarding fields (Phase 3)
    onboarding_completed = Column(Boolean, default=False)
    primary_goal = Column(String(100), nullable=True)  # sales, leadership, interviews, etc.

    # Profile fields
    bio = Column(Text, nullable=True)
    job_title = Column(String(255), nullable=True)

    # Persistent settings / preferences (JSON blob)
    preferences = Column(JSON, nullable=True)  # {live_nudges, voice_feedback, auto_mic, ...}

    organization = relationship("Organization", back_populates="users")
    sessions = relationship("TrainingSession", back_populates="user")
    feedback = relationship("Feedback", back_populates="user")
    skill_scores = relationship("SkillScore", back_populates="user")
