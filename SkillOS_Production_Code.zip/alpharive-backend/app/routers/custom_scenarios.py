"""
Custom Scenarios Router — allows users to create their own AI training scenarios.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.scenario import Scenario
from app.dependencies import get_current_user
from app.models.user import User
from pydantic import BaseModel
from typing import Optional

router = APIRouter(prefix="/scenarios/custom", tags=["Custom Scenarios"])


class CustomScenarioCreate(BaseModel):
    title: str
    description: str
    persona_name: str
    persona_role: str
    personality_prompt: str          # becomes system_prompt
    difficulty: str = "intermediate"
    skills_targeted: List[str] = ["confidence", "clarity"]
    duration_minutes: int = 10


@router.post("", status_code=201)
def create_custom_scenario(
    body: CustomScenarioCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Create a user-defined custom training scenario."""
    scenario = Scenario(
        title=body.title,
        description=body.description,
        category="custom",
        difficulty=body.difficulty,
        skills_targeted=body.skills_targeted,
        duration_minutes=body.duration_minutes,
        briefing=f"You are speaking with {body.persona_name}, {body.persona_role}. {body.description}",
        system_prompt=body.personality_prompt,
        is_published=True,
        is_custom=True,
        persona_name=body.persona_name,
        persona_role=body.persona_role,
        created_by=user.id,
    )
    db.add(scenario)
    db.commit()
    db.refresh(scenario)
    return {"id": scenario.id, "title": scenario.title, "message": "Custom scenario created"}


@router.get("/mine")
def list_my_custom_scenarios(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """List all custom scenarios created by this user."""
    scenarios = (
        db.query(Scenario)
        .filter(Scenario.created_by == user.id, Scenario.is_custom == True)
        .order_by(Scenario.created_at.desc())
        .all()
    )
    return [
        {
            "id": s.id,
            "title": s.title,
            "description": s.description,
            "persona_name": s.persona_name,
            "persona_role": s.persona_role,
            "difficulty": s.difficulty,
            "duration_minutes": s.duration_minutes,
            "play_count": s.play_count or 0,
            "created_at": s.created_at.isoformat(),
        }
        for s in scenarios
    ]


@router.delete("/{scenario_id}", status_code=204)
def delete_custom_scenario(
    scenario_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Delete a custom scenario (only the creator can delete it)."""
    scenario = db.query(Scenario).filter(
        Scenario.id == scenario_id,
        Scenario.created_by == user.id,
        Scenario.is_custom == True,
    ).first()
    if not scenario:
        raise HTTPException(status_code=404, detail="Custom scenario not found")
    db.delete(scenario)
    db.commit()
    return None
