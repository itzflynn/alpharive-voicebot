from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, cast, Date
from typing import List, Dict
from datetime import datetime, date, timedelta
from app.database import get_db
from app.models.session import TrainingSession
from app.models.feedback import Feedback
from app.models.skill_score import SkillScore
from app.models.scenario import Scenario
from app.dependencies import get_current_user
from app.models.user import User

router = APIRouter(prefix="/analytics", tags=["Analytics"])


def compute_streaks(db: Session, user_id: str) -> dict:
    """Compute current streak and longest streak from completed sessions."""
    # Get all distinct dates user completed a session (UTC date)
    rows = (
        db.query(func.date(TrainingSession.completed_at))
        .filter(
            TrainingSession.user_id == user_id,
            TrainingSession.status == "completed",
            TrainingSession.completed_at.isnot(None),
        )
        .distinct()
        .order_by(func.date(TrainingSession.completed_at).desc())
        .all()
    )

    # Convert to a sorted list of dates (most recent first)
    dates = sorted(
        {date.fromisoformat(r[0]) for r in rows if r[0]},
        reverse=True,
    )

    if not dates:
        return {"streak_days": 0, "longest_streak": 0}

    today = datetime.utcnow().date()

    # ── Current streak ─────────────────────────────────────────────────────────
    # A streak is active if the most recent session was today or yesterday
    current_streak = 0
    if dates[0] >= today - timedelta(days=1):
        expected = dates[0]
        for d in dates:
            if d == expected:
                current_streak += 1
                expected -= timedelta(days=1)
            else:
                break

    # ── Longest streak ─────────────────────────────────────────────────────────
    sorted_asc = sorted(dates)
    longest = 1
    run = 1
    for i in range(1, len(sorted_asc)):
        if sorted_asc[i] == sorted_asc[i - 1] + timedelta(days=1):
            run += 1
            longest = max(longest, run)
        else:
            run = 1

    return {"streak_days": current_streak, "longest_streak": longest}


@router.get("/summary")
def user_summary(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    total = db.query(TrainingSession).filter(
        TrainingSession.user_id == user.id,
        TrainingSession.status == "completed",
    ).count()

    avg_score = db.query(func.avg(Feedback.overall_score)).filter(
        Feedback.user_id == user.id
    ).scalar()

    best = db.query(func.max(Feedback.overall_score)).filter(
        Feedback.user_id == user.id
    ).scalar()

    streaks = compute_streaks(db, user.id)

    return {
        "sessions_completed": total,
        "average_score": round(avg_score or 0, 1),
        "best_score": round(best or 0, 1),
        "streak_days": streaks["streak_days"],
        "longest_streak": streaks["longest_streak"],
    }


@router.get("/skills")
def skill_breakdown(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.query(SkillScore.skill, func.avg(SkillScore.score)).filter(
        SkillScore.user_id == user.id
    ).group_by(SkillScore.skill).all()
    return {"skills": {r[0]: round(r[1], 1) for r in rows}}


@router.get("/skill-history")
def skill_history(
    skill: str = "confidence",
    limit: int = 20,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    rows = (
        db.query(SkillScore)
        .filter(SkillScore.user_id == user.id, SkillScore.skill == skill)
        .order_by(SkillScore.recorded_at.asc())
        .limit(limit)
        .all()
    )
    return {
        "skill": skill,
        "history": [{"score": r.score, "date": r.recorded_at.isoformat()} for r in rows],
    }


@router.get("/score-history")
def score_history(
    days: int = 30,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """
    Returns per-session score data for the last N days.
    Each row: { date, overall_score, confidence, clarity, tone, persuasion, filler_control }
    """
    since = datetime.utcnow() - timedelta(days=days)

    rows = (
        db.query(TrainingSession, Feedback, Scenario)
        .join(Feedback, Feedback.session_id == TrainingSession.id)
        .join(Scenario, Scenario.id == TrainingSession.scenario_id)
        .filter(
            TrainingSession.user_id == user.id,
            TrainingSession.status == "completed",
            TrainingSession.completed_at >= since,
        )
        .order_by(TrainingSession.completed_at.asc())
        .all()
    )

    result = []
    for session, fb, sc in rows:
        result.append({
            "date": session.completed_at.strftime("%b %d"),
            "date_iso": session.completed_at.isoformat(),
            "scenario_title": sc.title,
            "overall_score": round(fb.overall_score or 0, 1),
            "confidence": round(fb.confidence_score or 0, 1),
            "clarity": round(fb.clarity_score or 0, 1),
            "tone": round(fb.tone_score or 0, 1),
            "persuasion": round(fb.persuasion_score or 0, 1),
            "filler_control": round(fb.filler_control_score or 0, 1),
        })

    return {"history": result}


@router.get("/recent-sessions")
def recent_sessions(
    limit: int = 5,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    sessions = (
        db.query(TrainingSession, Scenario, Feedback)
        .join(Scenario, TrainingSession.scenario_id == Scenario.id)
        .outerjoin(Feedback, Feedback.session_id == TrainingSession.id)
        .filter(TrainingSession.user_id == user.id, TrainingSession.status == "completed")
        .order_by(TrainingSession.completed_at.desc())
        .limit(limit)
        .all()
    )
    result = []
    for s, sc, fb in sessions:
        result.append({
            "session_id": s.id,
            "scenario_title": sc.title,
            "category": sc.category,
            "completed_at": s.completed_at.isoformat() if s.completed_at else None,
            "overall_score": fb.overall_score if fb else None,
            "duration_seconds": s.duration_seconds,
        })
    return {"sessions": result}
