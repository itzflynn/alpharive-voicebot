from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks
from sqlalchemy.orm import Session
from typing import Optional
from app.database import get_db
from app.schemas.auth import RegisterRequest, LoginRequest, TokenResponse, RefreshRequest, UserOut
from app.services.auth_service import register_user, login_user, refresh_tokens
from app.dependencies import get_current_user
from app.models.user import User
from pydantic import BaseModel
from app.utils.rate_limit import limiter

router = APIRouter(prefix="/auth", tags=["Authentication"])


class UserUpdateRequest(BaseModel):
    full_name: Optional[str] = None
    onboarding_completed: Optional[bool] = None
    primary_goal: Optional[str] = None


@router.post("/register", response_model=TokenResponse, status_code=201)
@limiter.limit("5/minute")
def register(req: RegisterRequest, request: Request, db: Session = Depends(get_db)):
    return register_user(req, db)


@router.post("/login", response_model=TokenResponse)
@limiter.limit("10/minute")
def login(req: LoginRequest, request: Request, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    return login_user(req, db, background_tasks)


@router.post("/refresh", response_model=TokenResponse)
def refresh(req: RefreshRequest, db: Session = Depends(get_db)):
    return refresh_tokens(req.refresh_token, db)


@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(get_current_user)):
    return current_user


@router.patch("/me")
def update_me(
    body: UserUpdateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Update user profile — used for onboarding completion and goal setting."""
    if body.full_name is not None:
        current_user.full_name = body.full_name
    if body.onboarding_completed is not None:
        current_user.onboarding_completed = body.onboarding_completed
    if body.primary_goal is not None:
        current_user.primary_goal = body.primary_goal
    db.commit()
    db.refresh(current_user)
    return {
        "id": current_user.id,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "onboarding_completed": current_user.onboarding_completed,
        "primary_goal": current_user.primary_goal,
    }
