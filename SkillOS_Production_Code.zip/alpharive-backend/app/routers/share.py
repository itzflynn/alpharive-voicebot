"""
Public Share Router — no authentication required.
Serves sanitized session feedback via share token.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.session import TrainingSession
from app.models.feedback import Feedback
from app.models.scenario import Scenario
from app.models.user import User

router = APIRouter(prefix="/share", tags=["Share"])


@router.get("/{token}")
def get_shared_session(token: str, db: Session = Depends(get_db)):
    """Public endpoint — returns sanitized session data by share token."""
    session = db.query(TrainingSession).filter(
        TrainingSession.share_token == token
    ).first()

    if not session:
        raise HTTPException(status_code=404, detail="Shared session not found or link expired")

    feedback = db.query(Feedback).filter(Feedback.session_id == session.id).first()
    scenario = db.query(Scenario).filter(Scenario.id == session.scenario_id).first()
    user = db.query(User).filter(User.id == session.user_id).first()

    if not feedback:
        raise HTTPException(status_code=404, detail="Feedback not available yet")

    user_first_name = user.full_name.split(" ")[0] if user and user.full_name else "A user"

    return {
        "share_token": token,
        "user_first_name": user_first_name,
        "scenario_title": scenario.title if scenario else "Training Session",
        "scenario_category": scenario.category if scenario else "general",
        "overall_score": round(feedback.overall_score or 0, 1),
        "skill_scores": {
            "confidence": round(feedback.confidence_score or 0, 1),
            "clarity": round(feedback.clarity_score or 0, 1),
            "tone": round(feedback.tone_score or 0, 1),
            "persuasion": round(feedback.persuasion_score or 0, 1),
            "filler_control": round(feedback.filler_control_score or 0, 1),
        },
        "strengths": feedback.strengths or [],
        "improvements": feedback.improvements or [],
        "feedback_summary": (feedback.detailed_feedback or "")[:300],
        "scenario_id": str(session.scenario_id),
        "completed_at": session.completed_at.isoformat() if session.completed_at else None,
    }
