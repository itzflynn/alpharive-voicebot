"""
Sessions Router — voice sessions, webcam recording, sharing
"""
import os
import uuid
import subprocess
import logging
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.session import TrainingSession
from app.models.feedback import Feedback
from app.schemas.session import (
    SessionStartRequest, SessionStartResponse,
    SessionCompleteRequest, SessionOut, FeedbackOut,
)
from app.services.session_service import start_session, complete_session
from app.dependencies import get_current_user
from app.models.user import User
from app.models.scenario import Scenario
from app.config import settings
from pydantic import BaseModel

logger = logging.getLogger(__name__)

RECORDINGS_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "uploads", "recordings")
os.makedirs(RECORDINGS_DIR, exist_ok=True)


class MessageDict(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    text: str
    history: List[MessageDict] = []


router = APIRouter(prefix="/sessions", tags=["Sessions"])


@router.post("/start", response_model=SessionStartResponse, status_code=201)
def session_start(
    req: SessionStartRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return start_session(req, user, db)


@router.post("/{session_id}/complete")
async def session_complete(
    session_id: str,
    req: SessionCompleteRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await complete_session(session_id, req, user, db)


@router.post("/{session_id}/chat")
async def session_chat(
    session_id: str,
    req: ChatRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    # Load session & scenario for context
    session = db.query(TrainingSession).filter(
        TrainingSession.id == session_id,
        TrainingSession.user_id == user.id,
    ).first()

    scenario_title = "a professional communication scenario"
    scenario_category = "general"
    scenario_briefing = ""
    persona = "a professional interviewer"

    if session:
        scenario = db.query(Scenario).filter(Scenario.id == session.scenario_id).first()
        if scenario:
            scenario_title = scenario.title
            scenario_category = scenario.category or "general"
            scenario_briefing = scenario.briefing or ""
            if scenario.persona_name and scenario.persona_role:
                persona = f"{scenario.persona_name}, {scenario.persona_role}"
            else:
                personas = {
                    "sales": "a skeptical but fair enterprise buyer",
                    "customer_service": "a frustrated but reasonable customer",
                    "leadership": "a senior manager giving honest feedback",
                    "interviews": "a seasoned hiring manager",
                    "negotiation": "a tough but professional negotiation counterpart",
                }
                persona = personas.get(scenario_category, "a professional evaluator")

    text_lower = req.text.lower().strip()

    if settings.OPENAI_API_KEY and not settings.OPENAI_API_KEY.startswith("sk-your"):
        try:
            from openai import AsyncOpenAI
            client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

            system_prompt = f"""You are {persona} in a training roleplay scenario titled "{scenario_title}".
Context: {scenario_briefing}

Rules:
- Stay strictly in character as {persona}. Do NOT break character.
- Respond naturally to what the trainee says — if they greet you, greet back and set the scene.
- Keep responses concise (1-3 sentences). Ask probing follow-up questions.
- Be realistic: challenge weak arguments, acknowledge strong ones.
- Do NOT say "Interesting point. Can you elaborate?" unless it genuinely fits.
- Match the trainee's energy: if they're brief, ask a specific question to draw them out."""

            messages = [{"role": "system", "content": system_prompt}]
            for msg in req.history:
                messages.append({"role": msg.role, "content": msg.content})
            messages.append({"role": "user", "content": req.text})

            response = await client.chat.completions.create(
                model="gpt-4o-mini",
                messages=messages,
                temperature=0.7,
                max_tokens=150,
            )
            reply = response.choices[0].message.content.strip()
            return {"reply": reply}
        except Exception as e:
            logger.error(f"Chat LLM error: {e}")

    # ── Smart Rule-Based Fallback ──────────────────────────────────────────────
    word_count = len(req.text.split())
    greetings = ["hi", "hello", "hey", "good morning", "good afternoon", "howdy"]
    is_greeting = any(g in text_lower for g in greetings) and word_count <= 4

    if is_greeting:
        intros = {
            "sales": "Hello! Thanks for taking the time. I've been looking at a few vendors. Tell me — why should I choose your solution over the competition?",
            "interviews": "Good to meet you. I've reviewed your resume briefly. Walk me through your background and why you're interested in this role.",
            "customer_service": "Hi. I've been on hold for 20 minutes. I have a problem with my order and I need this resolved today.",
            "leadership": "Hey, glad you could make it. I wanted to have an honest conversation about how the team's been performing. What's your assessment?",
            "negotiation": "Good to see you. Before we begin, I want to say — our position has changed since we last spoke. Let's talk terms.",
        }
        reply = intros.get(scenario_category, "Good to meet you. Let's get started. Tell me — what brings you here today?")
    elif word_count < 4:
        probes = {
            "sales": "I need more than that. What specific value does your solution bring to a company like ours?",
            "interviews": "Could you expand on that? I'd like to understand your thinking in more depth.",
            "customer_service": "I'm not sure I follow. Can you explain what happened with your order specifically?",
            "leadership": "Can you be more specific? I need concrete examples, not just general statements.",
            "negotiation": "That's vague. What exactly are you proposing?",
        }
        reply = probes.get(scenario_category, "Could you elaborate on that point?")
    elif "price" in text_lower or "cost" in text_lower or "budget" in text_lower:
        reply = "Budget is always a factor. But let's talk value first — what problem are you actually trying to solve, and what's the cost of NOT solving it?"
    elif "competitor" in text_lower or "alternative" in text_lower:
        reply = "Fair point. I've looked at alternatives. What makes you confident your approach is the right fit for our specific situation?"
    elif "?" in req.text:
        reply = "That's a fair question. Before I answer, I want to understand where you're coming from — what's driving that concern for you?"
    elif word_count > 30:
        reply = "You've covered a lot there. Let me push back on one thing — what is the single most compelling reason I should say yes?"
    else:
        import hashlib
        follow_ups = [
            "What evidence do you have to support that?",
            "How would you handle it if I pushed back on that?",
            "Give me a specific example where that approach worked.",
            "That's a reasonable point. What's the risk if we go in a different direction?",
            "Okay — and what happens next if we agree on this?",
        ]
        idx = int(hashlib.md5(req.text.encode()).hexdigest(), 16) % len(follow_ups)
        reply = follow_ups[idx]

    return {"reply": reply}


# ── Webcam Recording Endpoints ─────────────────────────────────────────────────

@router.post("/{session_id}/recording/chunk")
async def recording_chunk(
    session_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Receive a binary video chunk and save it."""
    session = db.query(TrainingSession).filter(
        TrainingSession.id == session_id,
        TrainingSession.user_id == user.id,
    ).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    session_dir = os.path.join(RECORDINGS_DIR, session_id)
    os.makedirs(session_dir, exist_ok=True)

    # Count existing chunks
    existing_chunks = [f for f in os.listdir(session_dir) if f.startswith("chunk_") and f.endswith(".webm")]
    chunk_index = len(existing_chunks)

    chunk_path = os.path.join(session_dir, f"chunk_{chunk_index:04d}.webm")
    body = await request.body()
    with open(chunk_path, "wb") as f:
        f.write(body)

    return {"chunk_index": chunk_index, "size_bytes": len(body)}


@router.post("/{session_id}/recording/stop")
def recording_stop(
    session_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Concatenate all chunks into final.webm using ffmpeg."""
    session = db.query(TrainingSession).filter(
        TrainingSession.id == session_id,
        TrainingSession.user_id == user.id,
    ).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    session_dir = os.path.join(RECORDINGS_DIR, session_id)
    if not os.path.exists(session_dir):
        raise HTTPException(status_code=404, detail="No recording chunks found")

    chunks = sorted([f for f in os.listdir(session_dir) if f.startswith("chunk_") and f.endswith(".webm")])
    if not chunks:
        raise HTTPException(status_code=404, detail="No recording chunks found")

    final_path = os.path.join(session_dir, "final.webm")

    if len(chunks) == 1:
        # Single chunk — just rename
        os.rename(os.path.join(session_dir, chunks[0]), final_path)
    else:
        # Create ffmpeg concat list
        list_path = os.path.join(session_dir, "concat_list.txt")
        with open(list_path, "w") as f:
            for chunk in chunks:
                f.write(f"file '{os.path.join(session_dir, chunk)}'\n")
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", list_path, "-c", "copy", final_path],
                check=True, capture_output=True, timeout=60,
            )
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            logger.warning(f"ffmpeg concat failed ({e}), using last chunk as fallback")
            last_chunk_path = os.path.join(session_dir, chunks[-1])
            import shutil
            shutil.copy(last_chunk_path, final_path)

    recording_url = f"/sessions/{session_id}/recording"
    session.recording_url = recording_url
    db.commit()

    return {"recording_url": recording_url, "message": "Recording finalized"}


@router.get("/{session_id}/recording")
def get_recording(
    session_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Stream the final recording video."""
    session = db.query(TrainingSession).filter(
        TrainingSession.id == session_id,
        TrainingSession.user_id == user.id,
    ).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    final_path = os.path.join(RECORDINGS_DIR, session_id, "final.webm")
    if not os.path.exists(final_path):
        raise HTTPException(status_code=404, detail="Recording not found")

    return FileResponse(final_path, media_type="video/webm")


# ── Session Sharing ─────────────────────────────────────────────────────────────

@router.post("/{session_id}/share")
def share_session(
    session_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Generate a public share token for a session's feedback report."""
    session = db.query(TrainingSession).filter(
        TrainingSession.id == session_id,
        TrainingSession.user_id == user.id,
        TrainingSession.status == "completed",
    ).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found or not completed")

    if not session.share_token:
        session.share_token = str(uuid.uuid4()).replace("-", "")[:16]
        db.commit()

    return {"share_token": session.share_token, "share_url": f"/share/{session.share_token}"}


@router.get("/history", response_model=List[SessionOut])
def session_history(
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return (
        db.query(TrainingSession)
        .filter(TrainingSession.user_id == user.id)
        .order_by(TrainingSession.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


@router.get("/{session_id}", response_model=SessionOut)
def get_session(
    session_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    s = db.query(TrainingSession).filter(
        TrainingSession.id == session_id,
        TrainingSession.user_id == user.id,
    ).first()
    if not s:
        raise HTTPException(status_code=404, detail="Session not found")
    return s


@router.get("/{session_id}/feedback", response_model=FeedbackOut)
def get_feedback(
    session_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fb = db.query(Feedback).filter(
        Feedback.session_id == session_id,
        Feedback.user_id == user.id,
    ).first()
    if not fb:
        raise HTTPException(status_code=404, detail="Feedback not yet generated")
    return fb
