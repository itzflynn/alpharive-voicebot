from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List
import time
import logging

from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.models.meeting import MeetingBot

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/bot", tags=["Meeting Bots"])

class DeployBotRequest(BaseModel):
    meeting_url: str
    bot_name: str = "SkillOS Notetaker"

class BotResponse(BaseModel):
    id: str
    meeting_url: str
    platform: str
    status: str
    bot_name: str
    created_at: str

    class Config:
        from_attributes = True

def _simulate_bot_join(bot_id: str):
    from app.database import SessionLocal
    # Simulate deploying cloud infrastructure (e.g., AWS ECS + Puppeteer)
    time.sleep(5)
    db = SessionLocal()
    try:
        bot = db.query(MeetingBot).filter(MeetingBot.id == bot_id).first()
        if bot:
            bot.status = "joined"
            db.commit()
            logger.info(f"Bot {bot_id} successfully joined {bot.meeting_url}")
    finally:
        db.close()

@router.post("/deploy")
def deploy_bot(
    req: DeployBotRequest,
    bg_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    platform = "zoom" if "zoom.us" in req.meeting_url.lower() else "meet" if "meet.google" in req.meeting_url.lower() else "teams" if "teams.microsoft" in req.meeting_url.lower() else "unknown"
    
    bot = MeetingBot(
        user_id=user.id,
        meeting_url=req.meeting_url,
        platform=platform,
        status="deploying",
        bot_name=req.bot_name,
    )
    db.add(bot)
    db.commit()
    db.refresh(bot)
    
    bg_tasks.add_task(_simulate_bot_join, bot.id)
    
    return bot

@router.get("/history")
def get_bots(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.query(MeetingBot).filter(MeetingBot.user_id == user.id).order_by(MeetingBot.created_at.desc()).all()
