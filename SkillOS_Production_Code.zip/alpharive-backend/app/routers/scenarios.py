from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.database import get_db
from app.models.scenario import Scenario
from app.schemas.scenario import ScenarioCreate, ScenarioUpdate, ScenarioOut
from app.dependencies import get_current_user, require_admin
from app.models.user import User

router = APIRouter(prefix="/scenarios", tags=["Scenarios"])


@router.get("", response_model=List[ScenarioOut])
def list_scenarios(
    category: Optional[str] = Query(None),
    difficulty: Optional[str] = Query(None),
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    q = db.query(Scenario).filter(Scenario.is_published == True)
    if category:
        q = q.filter(Scenario.category == category)
    if difficulty:
        q = q.filter(Scenario.difficulty == difficulty)
    return q.order_by(Scenario.play_count.desc()).offset(skip).limit(limit).all()


@router.get("/categories")
def list_categories(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    rows = db.query(Scenario.category).filter(Scenario.is_published == True).distinct().all()
    return {"categories": [r[0] for r in rows if r[0]]}


@router.get("/{scenario_id}", response_model=ScenarioOut)
def get_scenario(
    scenario_id: str,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    s = db.query(Scenario).filter(Scenario.id == scenario_id, Scenario.is_published == True).first()
    if not s:
        raise HTTPException(status_code=404, detail="Scenario not found")
    return s


@router.post("", response_model=ScenarioOut, status_code=201)
def create_scenario(
    req: ScenarioCreate,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    scenario = Scenario(**req.model_dump(), created_by=admin.id, org_id=admin.org_id)
    db.add(scenario)
    db.commit()
    db.refresh(scenario)
    return scenario


@router.put("/{scenario_id}", response_model=ScenarioOut)
def update_scenario(
    scenario_id: str,
    req: ScenarioUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    s = db.query(Scenario).filter(Scenario.id == scenario_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Scenario not found")
    for k, v in req.model_dump(exclude_none=True).items():
        setattr(s, k, v)
    db.commit()
    db.refresh(s)
    return s


@router.delete("/{scenario_id}", status_code=204)
def delete_scenario(
    scenario_id: str,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    s = db.query(Scenario).filter(Scenario.id == scenario_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Scenario not found")
    db.delete(s)
    db.commit()
