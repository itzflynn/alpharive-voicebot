import sqlite3
import os

db_path = os.path.join(os.path.dirname(__file__), "alpharive.db")
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

try:
    cursor.execute("ALTER TABLE feedback ADD COLUMN pronunciation_score FLOAT;")
    cursor.execute("ALTER TABLE feedback ADD COLUMN pronunciation_feedback TEXT;")
except Exception as e:
    print("Pronunciation col error:", e)

try:
    cursor.execute("""
    CREATE TABLE meeting_bots (
        id VARCHAR PRIMARY KEY,
        user_id VARCHAR REFERENCES users(id),
        meeting_url VARCHAR,
        platform VARCHAR,
        status VARCHAR,
        bot_name VARCHAR,
        created_at DATETIME
    );
    """)
except Exception as e:
    print("Meetings table error:", e)

conn.commit()
conn.close()
print("Done")
