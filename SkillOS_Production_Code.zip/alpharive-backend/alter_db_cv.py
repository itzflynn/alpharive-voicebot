import sqlite3
import os

db_path = os.path.join(os.path.dirname(__file__), "alpharive.db")
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

try:
    cursor.execute("ALTER TABLE feedback ADD COLUMN eye_contact_score FLOAT;")
except Exception as e:
    print("Eye contact column:", e)

try:
    cursor.execute("ALTER TABLE feedback ADD COLUMN smile_score FLOAT;")
except Exception as e:
    print("Smile score column:", e)

conn.commit()
conn.close()
print("Database altered.")
