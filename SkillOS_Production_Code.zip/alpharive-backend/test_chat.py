import requests

url = "http://localhost:8000/sessions/test-id/chat"
headers = {"Content-Type": "application/json"}
# We might need authentication, let's see if we get 401
response = requests.post(url, json={"text": "hi hello"}, headers=headers)
print("Status:", response.status_code)
print("Body:", response.text)
