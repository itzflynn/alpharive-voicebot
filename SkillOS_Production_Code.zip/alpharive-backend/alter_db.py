import sqlite3

conn = sqlite3.connect('alpharive.db')
cursor = conn.cursor()
try:
    cursor.execute("ALTER TABLE feedback ADD COLUMN pacing_wpm INTEGER")
    print("Added pacing_wpm")
except sqlite3.OperationalError as e:
    print(e)
    
try:
    cursor.execute("ALTER TABLE feedback ADD COLUMN rephrasing_suggestions JSON")
    print("Added rephrasing_suggestions")
except sqlite3.OperationalError as e:
    print(e)
    
conn.commit()
conn.close()
