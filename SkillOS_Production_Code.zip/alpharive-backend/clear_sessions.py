import sys
import os

# Add backend dir to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.database import SessionLocal
from app.models.user import User
from app.models.organization import Organization
from app.models.scenario import Scenario
from app.models.session import TrainingSession
from app.models.feedback import Feedback
from app.models.skill_score import SkillScore

db = SessionLocal()
db.query(Feedback).delete()
db.query(SkillScore).delete()
db.query(TrainingSession).delete()
db.commit()
print("Cleared all sessions")
