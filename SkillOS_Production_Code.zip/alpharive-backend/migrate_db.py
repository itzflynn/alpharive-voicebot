"""
Database migration — safely adds new columns to existing tables.
Run: python migrate_db.py
Safe to run multiple times (uses IF NOT EXISTS checks for SQLite).
"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "alpharive.db")

MIGRATIONS = [
    # sessions table additions
    "ALTER TABLE sessions ADD COLUMN recording_url TEXT",
    "ALTER TABLE sessions ADD COLUMN share_token TEXT",

    # feedback table additions
    "ALTER TABLE feedback ADD COLUMN vocabulary_analysis JSON",

    # users table additions
    "ALTER TABLE users ADD COLUMN onboarding_completed BOOLEAN DEFAULT 0",
    "ALTER TABLE users ADD COLUMN primary_goal TEXT",

    # scenarios table additions
    "ALTER TABLE scenarios ADD COLUMN is_custom BOOLEAN DEFAULT 0",
    "ALTER TABLE scenarios ADD COLUMN persona_name TEXT",
    "ALTER TABLE scenarios ADD COLUMN persona_role TEXT",
]


def migrate():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    applied = 0
    skipped = 0
    for sql in MIGRATIONS:
        try:
            cur.execute(sql)
            conn.commit()
            applied += 1
            print(f"  [OK] {sql[:60]}...")
        except sqlite3.OperationalError as e:
            if "duplicate column" in str(e).lower():
                skipped += 1
                print(f"  [SKIP] Already exists: {sql.split('ADD COLUMN')[1].strip().split()[0]}")
            else:
                print(f"  [ERR] {e} | SQL: {sql}")
    conn.close()
    print(f"\nMigration complete: {applied} applied, {skipped} skipped.")


if __name__ == "__main__":
    migrate()
