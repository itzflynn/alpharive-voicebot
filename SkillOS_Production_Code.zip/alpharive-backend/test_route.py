import urllib.request
import urllib.error
import json

req = urllib.request.Request("http://localhost:8000/sessions/test/chat", data=json.dumps({"text": "hi"}).encode("utf-8"), headers={"Content-Type": "application/json"}, method="POST")
try:
    response = urllib.request.urlopen(req)
    print("Code:", response.getcode())
    print("Body:", response.read().decode())
except urllib.error.HTTPError as e:
    print("HTTPError Code:", e.code)
    print("Body:", e.read().decode())
except Exception as e:
    print("Error:", e)
