"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import Logo from "@/components/Logo";

const FEATURES = [
  {
    icon: "🎙️",
    title: "Voice-First AI Coach",
    desc: "Speak naturally. SkillOS listens in real-time, transcribes, and responds as a human-like AI persona — giving you an authentic training experience.",
    color: "#E50914",
  },
  {
    icon: "⚡",
    title: "Live Performance Nudges",
    desc: "Instant alerts when you use filler words, speak too fast, or go off-track. Real-time coaching without waiting for the session to end.",
    color: "#f59e0b",
  },
  {
    icon: "🧠",
    title: "AI Evaluation Engine",
    desc: "Proprietary scoring across 5 dimensions — Confidence, Clarity, Tone, Persuasion, and Filler Control. Honest. Detailed. Actionable.",
    color: "#22c55e",
  },
  {
    icon: "🎭",
    title: "10+ Real Scenarios",
    desc: "Cold calls, price objections, difficult leadership conversations, job interviews, and high-stakes negotiations — all AI-powered.",
    color: "#a78bfa",
  },
  {
    icon: "📊",
    title: "Analytics Dashboard",
    desc: "Track your skill progression over time with session history, skill breakdowns, pacing metrics, and rephrasing suggestions.",
    color: "#22d3ee",
  },
  {
    icon: "🔒",
    title: "Private & Secure",
    desc: "Your practice sessions stay private. No public leaderboards, no shared recordings. A judgment-free zone to build real skills.",
    color: "#f472b6",
  },
];

const STATS = [
  { value: "50+", label: "Training Scenarios" },
  { value: "5", label: "Skill Dimensions" },
  { value: "Real-Time", label: "AI Feedback" },
  { value: "∞", label: "Practice Sessions" },
];

const TESTIMONIALS = [
  {
    name: "Priya Sharma",
    role: "Sales Director, TechCorp",
    avatar: "PS",
    text: "SkillOS transformed how our sales team prepares for enterprise deals. The AI feedback is shockingly accurate — it catches things our managers miss.",
    rating: 5,
  },
  {
    name: "Rahul Menon",
    role: "HR Head, Infosys",
    avatar: "RM",
    text: "We use SkillOS for interview coaching. Candidates who practice on it consistently outperform in real interviews. It's become a core part of our L&D stack.",
    rating: 5,
  },
  {
    name: "Ananya Gupta",
    role: "Founder, GrowthLab",
    avatar: "AG",
    text: "The live filler-word detection alone was worth it. I went from saying 'um' 30 times in a pitch to zero in just two weeks. Investors noticed immediately.",
    rating: 5,
  },
];

const PLANS = [
  {
    name: "Starter",
    price: "Free",
    sub: "Forever",
    features: ["5 sessions/month", "3 scenarios", "Basic feedback", "Email support"],
    cta: "Get Started Free",
    href: "/register",
    highlight: false,
  },
  {
    name: "Professional",
    price: "₹2,499",
    sub: "per month",
    features: ["Unlimited sessions", "All 50+ scenarios", "AI voice feedback", "Pacing & WPM analytics", "Rephrasing suggestions", "Priority support"],
    cta: "Start Free Trial",
    href: "/register",
    highlight: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    sub: "per team",
    features: ["Everything in Pro", "Team analytics", "Custom scenarios", "Dedicated coach AI", "SSO & admin panel", "SLA guarantee"],
    cta: "Contact Sales",
    href: "/register",
    highlight: false,
  },
];

export default function LandingPage() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div style={{ background: "var(--bg-primary)", minHeight: "100vh", overflowX: "hidden" }}>

      {/* ── Nav ── */}
      <nav style={{
        position: "sticky", top: 0, zIndex: 200,
        background: scrolled ? "rgba(8,8,8,0.95)" : "transparent",
        backdropFilter: scrolled ? "blur(20px)" : "none",
        borderBottom: scrolled ? "1px solid var(--border)" : "1px solid transparent",
        transition: "all 0.3s ease",
        padding: "0 48px", height: 64,
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <Logo />
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Link href="/login" className="btn btn-ghost btn-sm">Sign In</Link>
          <Link href="/register" className="btn btn-primary btn-sm">Get Started Free</Link>
        </div>
      </nav>

      {/* ── Hero ── */}
      <section style={{ position: "relative", padding: "100px 48px 80px", textAlign: "center", overflow: "hidden" }}>
        {/* Orbs */}
        <div className="orb orb-red animate-float" style={{ width: 600, height: 600, top: -200, left: "50%", transform: "translateX(-50%)", opacity: 0.4 }} />
        <div className="orb orb-dark" style={{ width: 400, height: 400, top: 100, right: -100 }} />
        <div className="orb orb-dark" style={{ width: 300, height: 300, bottom: 0, left: -50 }} />

        <div style={{ position: "relative", zIndex: 1, maxWidth: 900, margin: "0 auto" }}>
          <div className="badge badge-red animate-fadeup" style={{ marginBottom: 28, fontSize: "0.75rem" }}>
            🚀 AI-Powered Communication Coach
          </div>

          <h1 className="heading-xl animate-fadeup delay-1" style={{ marginBottom: 24 }}>
            Master Every High-Stakes<br />
            <span className="text-gradient">Conversation with AI</span>
          </h1>

          <p className="animate-fadeup delay-2" style={{
            fontSize: "clamp(1rem,2vw,1.2rem)", color: "var(--text-secondary)",
            maxWidth: 640, margin: "0 auto 48px", lineHeight: 1.7
          }}>
            Practice real-world scenarios with AI personas. Get instant, honest feedback on your confidence, clarity, tone, and persuasion — in real time.
          </p>

          <div className="animate-fadeup delay-3" style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap" }}>
            <Link href="/register" className="btn btn-primary btn-lg">
              Start Training Free →
            </Link>
            <Link href="/login" className="btn btn-secondary btn-lg">
              Sign In
            </Link>
          </div>
        </div>

        {/* Stats bar */}
        <div style={{ maxWidth: 800, margin: "72px auto 0", position: "relative", zIndex: 1 }}>
          <div className="card" style={{
            display: "grid", gridTemplateColumns: "repeat(4,1fr)",
            padding: "28px 40px", gap: 0,
            background: "rgba(255,255,255,0.04)",
            borderColor: "rgba(229,9,20,0.2)",
          }}>
            {STATS.map((s, i) => (
              <div key={s.label} style={{
                textAlign: "center", padding: "0 20px",
                borderRight: i < STATS.length - 1 ? "1px solid var(--border)" : "none",
              }}>
                <div style={{ fontSize: "2rem", fontWeight: 900, color: "var(--accent-light)", letterSpacing: "-0.02em" }}>{s.value}</div>
                <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)", marginTop: 4, fontWeight: 500 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features ── */}
      <section style={{ padding: "80px 48px", maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <div className="badge badge-gray" style={{ marginBottom: 16 }}>FEATURES</div>
          <h2 className="heading-lg" style={{ marginBottom: 16 }}>
            Everything you need to<br /><span className="text-gradient">communicate at your best</span>
          </h2>
          <p style={{ color: "var(--text-secondary)", maxWidth: 500, margin: "0 auto", lineHeight: 1.7 }}>
            Built for professionals who want to win in the room — every time.
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(330px,1fr))", gap: 20 }}>
          {FEATURES.map((f, i) => (
            <div key={f.title} className="card-premium" style={{ padding: "32px 28px", animationDelay: `${i * 0.05}s` }}>
              <div style={{
                width: 52, height: 52, borderRadius: 14, marginBottom: 20,
                background: `${f.color}18`,
                border: `1px solid ${f.color}30`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: "1.6rem",
              }}>
                {f.icon}
              </div>
              <h3 style={{ fontWeight: 700, marginBottom: 10, fontSize: "1.05rem" }}>{f.title}</h3>
              <p style={{ color: "var(--text-secondary)", fontSize: "0.88rem", lineHeight: 1.7 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── How it works ── */}
      <section style={{ padding: "80px 48px", background: "rgba(255,255,255,0.02)", borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)" }}>
        <div style={{ maxWidth: 1000, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 60 }}>
            <div className="badge badge-red" style={{ marginBottom: 16 }}>HOW IT WORKS</div>
            <h2 className="heading-lg">Three steps to <span className="text-gradient">confident communication</span></h2>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 40 }}>
            {[
              { step: "01", title: "Choose a Scenario", desc: "Pick from 50+ real-world scenarios — sales calls, interviews, negotiations, or leadership conversations.", icon: "🎯" },
              { step: "02", title: "Practice with AI", desc: "Speak naturally. The AI responds in character, challenges your arguments, and keeps the conversation real.", icon: "🎙️" },
              { step: "03", title: "Get Honest Feedback", desc: "Receive a detailed score across 5 dimensions with specific examples, rephrasing suggestions, and an improvement plan.", icon: "📊" },
            ].map((s) => (
              <div key={s.step} style={{ textAlign: "center" }}>
                <div style={{ fontSize: "0.7rem", fontWeight: 800, color: "var(--accent)", letterSpacing: "0.1em", marginBottom: 16 }}>{s.step}</div>
                <div style={{ fontSize: "3rem", marginBottom: 16 }}>{s.icon}</div>
                <h3 style={{ fontWeight: 700, marginBottom: 10 }}>{s.title}</h3>
                <p style={{ color: "var(--text-secondary)", fontSize: "0.88rem", lineHeight: 1.7 }}>{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Testimonials ── */}
      <section style={{ padding: "80px 48px", maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <div className="badge badge-green" style={{ marginBottom: 16 }}>TESTIMONIALS</div>
          <h2 className="heading-lg">Trusted by professionals <span className="text-gradient">across India</span></h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))", gap: 20 }}>
          {TESTIMONIALS.map((t) => (
            <div key={t.name} className="card-premium" style={{ padding: "28px 24px" }}>
              <div style={{ display: "flex", gap: 4, marginBottom: 16 }}>
                {[...Array(t.rating)].map((_, i) => <span key={i} style={{ color: "#f59e0b", fontSize: "0.9rem" }}>★</span>)}
              </div>
              <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", lineHeight: 1.7, marginBottom: 20, fontStyle: "italic" }}>"{t.text}"</p>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div className="user-avatar" style={{ fontSize: "0.75rem" }}>{t.avatar}</div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: "0.9rem" }}>{t.name}</div>
                  <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Pricing ── */}
      <section style={{ padding: "80px 48px", background: "rgba(255,255,255,0.02)", borderTop: "1px solid var(--border)" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 60 }}>
            <div className="badge badge-purple" style={{ marginBottom: 16 }}>PRICING</div>
            <h2 className="heading-lg">Simple, transparent <span className="text-gradient">pricing</span></h2>
            <p style={{ color: "var(--text-secondary)", marginTop: 12 }}>No hidden fees. Cancel anytime.</p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20 }}>
            {PLANS.map((p) => (
              <div key={p.name} style={{
                padding: "36px 28px", borderRadius: "var(--radius-lg)",
                background: p.highlight ? "rgba(229,9,20,0.08)" : "var(--bg-card)",
                border: p.highlight ? "2px solid var(--accent)" : "1px solid var(--border)",
                position: "relative", transition: "var(--transition)",
              }}>
                {p.highlight && (
                  <div className="badge badge-red" style={{ position: "absolute", top: -14, left: "50%", transform: "translateX(-50%)" }}>
                    MOST POPULAR
                  </div>
                )}
                <div style={{ marginBottom: 24 }}>
                  <div style={{ fontWeight: 700, fontSize: "1rem", marginBottom: 8 }}>{p.name}</div>
                  <div style={{ fontSize: "2.4rem", fontWeight: 900, letterSpacing: "-0.03em", color: p.highlight ? "var(--accent-light)" : "var(--text-primary)" }}>{p.price}</div>
                  <div style={{ fontSize: "0.8rem", color: "var(--text-muted)", marginTop: 4 }}>{p.sub}</div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 28 }}>
                  {p.features.map((f) => (
                    <div key={f} style={{ display: "flex", gap: 10, alignItems: "flex-start", fontSize: "0.875rem" }}>
                      <span style={{ color: "var(--success)", flexShrink: 0, marginTop: 1 }}>✓</span>
                      <span style={{ color: "var(--text-secondary)" }}>{f}</span>
                    </div>
                  ))}
                </div>
                <Link href={p.href} className={`btn w-full ${p.highlight ? "btn-primary" : "btn-secondary"}`}>
                  {p.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section style={{ padding: "100px 48px", textAlign: "center", position: "relative", overflow: "hidden" }}>
        <div className="orb orb-red" style={{ width: 500, height: 500, top: "50%", left: "50%", transform: "translate(-50%,-50%)", opacity: 0.25 }} />
        <div style={{ position: "relative", zIndex: 1 }}>
          <h2 className="heading-lg" style={{ marginBottom: 20 }}>
            Ready to become a<br /><span className="text-gradient">master communicator?</span>
          </h2>
          <p style={{ color: "var(--text-secondary)", marginBottom: 40, maxWidth: 480, margin: "0 auto 40px", lineHeight: 1.7 }}>
            Join thousands of professionals using SkillOS to win more deals, ace interviews, and lead with confidence.
          </p>
          <Link href="/register" className="btn btn-primary btn-lg" style={{ boxShadow: "0 0 60px rgba(229,9,20,0.4)" }}>
            Start for Free — No Credit Card →
          </Link>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer style={{ borderTop: "1px solid var(--border)", padding: "40px 48px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Logo />
        <div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>
          © 2026 SkillOS. All rights reserved.
        </div>
        <div style={{ display: "flex", gap: 24, fontSize: "0.8rem" }}>
          {["Privacy", "Terms", "Contact"].map((l) => (
            <span key={l} style={{ color: "var(--text-muted)", cursor: "pointer", transition: "var(--transition)" }}
              onMouseEnter={(e) => (e.currentTarget.style.color = "var(--text-primary)")}
              onMouseLeave={(e) => (e.currentTarget.style.color = "var(--text-muted)")}>
              {l}
            </span>
          ))}
        </div>
      </footer>
    </div>
  );
}
