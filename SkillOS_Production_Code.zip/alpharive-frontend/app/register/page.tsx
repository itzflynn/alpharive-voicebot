"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { authApi } from "@/lib/api";
import Logo from "@/components/Logo";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: "", password: "", first_name: "", last_name: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const { data } = await authApi.register(form);
      localStorage.setItem("access_token", data.access_token);
      localStorage.setItem("refresh_token", data.refresh_token);
      router.push("/dashboard");
    } catch (err: any) {
      let msg = "Registration failed";
      if (err.response?.data?.detail) {
        if (typeof err.response.data.detail === "string") {
          msg = err.response.data.detail;
        } else if (Array.isArray(err.response.data.detail)) {
          msg = err.response.data.detail.map((d: any) => `${d.loc?.[d.loc?.length - 1]}: ${d.msg}`).join(", ");
        }
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "24px" }}>
      <div style={{ position: "fixed", top: "30%", right: "15%", width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, rgba(179,179,179,0.1) 0%, transparent 70%)", filter: "blur(80px)", pointerEvents: "none" }} />
      <div className="card w-full max-w-[480px] p-10 md:p-12">
        <Link href="/" className="inline-block mb-8">
          <Logo />
        </Link>
        <h1 className="text-3xl font-bold mb-2">Start your training</h1>
        <p className="text-sm font-normal text-white/50 leading-relaxed mb-8">Create your workspace and get instant access.</p>

        <form onSubmit={submit} className="flex flex-col gap-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="input-group">
              <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">First Name</label>
              <input className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg placeholder:text-white/30 focus:border-red-600 focus:ring-1 focus:ring-red-600" placeholder="Alex" value={form.first_name} onChange={set("first_name")} required />
            </div>
            <div className="input-group">
              <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Last Name</label>
              <input className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg placeholder:text-white/30 focus:border-red-600 focus:ring-1 focus:ring-red-600" placeholder="Johnson" value={form.last_name} onChange={set("last_name")} required />
            </div>
          </div>
          <div className="input-group">
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Work Email</label>
            <input type="email" className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg placeholder:text-white/30 focus:border-red-600 focus:ring-1 focus:ring-red-600" placeholder="alex@acme.com" value={form.email} onChange={set("email")} required />
          </div>
          <div className="input-group">
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Password</label>
            <input type="password" className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg placeholder:text-white/30 focus:border-red-600 focus:ring-1 focus:ring-red-600" placeholder="Min 8 characters" value={form.password} onChange={set("password")} required minLength={8} />
          </div>
          {error && <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/30 p-3 rounded-lg">{error}</p>}
          <button id="register-btn" type="submit" className="btn btn-primary h-11 px-6 text-base font-semibold w-full mt-2" disabled={loading}>
            {loading ? <span className="spinner w-5 h-5 border-t-white" /> : "Create Account & Start Training →"}
          </button>
        </form>

        <p className="text-center mt-8 text-sm text-white/50">
          Already have an account? <Link href="/login" className="text-red-400 font-semibold hover:text-red-300">Sign in</Link>
        </p>
      </div>
    </main>
  );
}
