import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SkillOS — AI Communication Training",
  description: "Master high-stakes communication with AI-powered training scenarios. Practice sales, leadership, interviews, and negotiations with real-time AI feedback.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
