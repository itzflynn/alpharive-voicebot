"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { shareApi } from "@/lib/api";

const SKILL_COLORS: Record<string, string> = {
  confidence: "#E50914",
  clarity: "#22d3ee",
  tone: "#a78bfa",
  persuasion: "#f59e0b",
  filler_control: "#22c55e",
};

const SKILL_ICONS: Record<string, string> = {
  confidence: "💪",
  clarity: "🔍",
  tone: "🎵",
  persuasion: "🎯",
  filler_control: "🤐",
};

function AnimatedGauge({ score }: { score: number }) {
  const color = score >= 70 ? "#10b981" : score >= 50 ? "#f59e0b" : "#ef4444";
  const r = 70, circ = 2 * Math.PI * r;
  const dash = circ * (score / 100);
    <div className="relative w-[180px] h-[180px]">
      <svg width="180" height="180" style={{ transform: "rotate(-90deg)" }}>
        <circle cx="90" cy="90" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="14" />
        <circle cx="90" cy="90" r={r} fill="none" stroke={color} strokeWidth="14"
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
          style={{ transition: "stroke-dasharray 1.2s ease" }} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-[2.8rem] font-bold tracking-tight" style={{ color }}>
          {Math.round(score)}
        </div>
        <div className="text-xs font-medium text-white/50">out of 100</div>
      </div>
    </div>
  );
}

export default function SharedSessionPage() {
  const { token } = useParams<{ token: string }>();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    shareApi.get(token)
      .then((r) => setData(r.data))
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [token]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a]">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-red-600/30 border-t-red-600 rounded-full animate-spin mx-auto mb-4" />
        <p className="text-white/50">Loading session results...</p>
      </div>
    </div>
  );

  if (error || !data) return (
    <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a]">
      <div className="text-center p-12">
        <div className="text-5xl mb-4">🔗</div>
        <h2 className="text-xl font-semibold mb-3">Link Not Found</h2>
        <p className="text-white/50 mb-7">This shared session link has expired or doesn't exist.</p>
        <Link href="/" className="btn btn-primary h-11 px-6 text-base font-semibold">
          Try SkillOS Free →
        </Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Header */}
      <div className="border-b border-white/10 px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center text-lg">⚡</div>
          <span className="font-bold text-lg tracking-tight">SkillOS</span>
        </div>
        <Link href="/register" className="btn btn-primary h-9 px-4 text-sm font-medium">
          Try for Free
        </Link>
      </div>

      <div className="max-w-[680px] mx-auto py-12 px-6">
        {/* Hero card */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-10 mb-7 text-center">
          <div className="text-[10px] font-bold text-red-600 uppercase tracking-wider mb-2">
            Session Results
          </div>
          <h1 className="text-3xl font-bold mb-2">
            {data.user_first_name}'s AI Coaching Session
          </h1>
          <p className="text-sm font-normal text-white/50 leading-relaxed mb-8">
            {data.scenario_title}
          </p>

          <div className="flex justify-center mb-5">
            <AnimatedGauge score={data.overall_score} />
          </div>

          <div className={`inline-block px-4 py-2 rounded-full border text-sm font-semibold ${data.overall_score >= 80 ? 'bg-green-500/10 border-green-500/30 text-green-400' : data.overall_score >= 60 ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' : 'bg-red-500/10 border-red-500/30 text-red-400'}`}>
            {data.overall_score >= 80 ? "🏆 Excellent Performance" : data.overall_score >= 60 ? "📈 Good Progress" : "💪 Keep Practicing"}
          </div>
        </div>

        {/* Skill breakdown */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-7 mb-7">
          <h2 className="text-base font-semibold mb-5">Skill Breakdown</h2>
          {Object.entries(data.skill_scores || {}).map(([skill, score]: [string, any]) => (
            <div key={skill} className="mb-4">
              <div className="flex justify-between mb-1.5">
                <span className="text-sm text-white/70">
                  {SKILL_ICONS[skill]} {skill.replace("_", " ").replace(/\b\w/g, (c) => c.toUpperCase())}
                </span>
                <span className="text-sm font-bold" style={{ color: SKILL_COLORS[skill] || "#fff" }}>{Math.round(score)}</span>
              </div>
              <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-1000 ease-out" style={{ width: `${score}%`, background: SKILL_COLORS[skill] || "#E50914" }} />
              </div>
            </div>
          ))}
        </div>

        {/* Strengths / Improvements */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-7">
          <div className="bg-green-500/5 border border-green-500/20 rounded-2xl p-5">
            <div className="text-xs font-bold text-green-500 uppercase tracking-wider mb-3">✅ What they did well</div>
            <ul className="flex flex-col gap-2">
              {(data.strengths || []).map((s: string, i: number) => (
                <li key={i} className="text-sm leading-relaxed text-white/70 flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full inline-block flex-shrink-0 mt-2 bg-green-500"></span>
                  <span>{s}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-5">
            <div className="text-xs font-bold text-amber-500 uppercase tracking-wider mb-3">🚀 Areas to grow</div>
            <ul className="flex flex-col gap-2">
              {(data.improvements || []).map((s: string, i: number) => (
                <li key={i} className="text-sm leading-relaxed text-white/70 flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full inline-block flex-shrink-0 mt-2 bg-amber-500"></span>
                  <span>{s}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center p-10 bg-red-600/5 border border-red-600/20 rounded-2xl">
          <div className="text-2xl mb-3">🎙️</div>
          <h2 className="text-xl font-bold mb-2">Ready to practice this yourself?</h2>
          <p className="text-sm font-normal text-white/50 leading-relaxed mb-6">
            Join thousands of professionals training with AI on SkillOS. Free to start.
          </p>
          <Link href={`/register`} className="btn btn-primary h-11 px-6 text-base font-semibold shadow-[0_0_30px_rgba(229,9,20,0.4)]">
            Practice this scenario yourself →
          </Link>
        </div>

        {/* Footer */}
        <div className="text-center mt-10 text-xs text-white/30">
          Powered by <strong className="text-white/50 font-normal">SkillOS</strong> — AI Communication Coach
        </div>
      </div>
    </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
