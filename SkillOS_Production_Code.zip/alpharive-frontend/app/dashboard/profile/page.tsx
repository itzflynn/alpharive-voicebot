"use client";
import { useEffect, useState } from "react";
import { authApi } from "@/lib/api";

export default function ProfilePage() {
  const [user, setUser] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [name, setName] = useState("");

  useEffect(() => {
    authApi.me().then((r) => {
      setUser(r.data);
      setName(r.data.full_name || "");
    });
  }, []);

  const initials = user?.full_name?.split(" ").map((n: string) => n[0]).join("").toUpperCase().slice(0, 2) || "U";

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await new Promise((r) => setTimeout(r, 800));
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const SKILL_LABELS: Record<string, string> = {
    confidence: "Confidence 💪", clarity: "Clarity 🔍",
    tone: "Tone 🎵", persuasion: "Persuasion 🎯", filler_control: "Filler Control 🤐",
  };

  return (
    <div className="max-w-[800px] w-full">
      <div className="mb-8 space-y-1">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white/40 mb-3">
          <span>Account</span>
          <span>›</span>
          <span className="text-white/70">Profile</span>
        </div>
        <h1 className="text-3xl font-bold">My Profile</h1>
        <p className="text-sm font-normal text-white/50 leading-relaxed">Manage your personal information and training preferences.</p>
      </div>

      {/* Avatar card */}
      <div className="card p-8 mb-6 flex gap-6 items-center">
        <div className="w-[88px] h-[88px] rounded-full bg-gradient-to-br from-red-600 to-purple-600 flex items-center justify-center text-3xl font-bold text-white shadow-[0_0_40px_rgba(229,9,20,0.2)] flex-shrink-0">
          {initials}
        </div>
        <div>
          <div className="text-xl font-bold mb-1">{user?.full_name || "—"}</div>
          <div className="text-sm font-normal text-white/50 mb-3">{user?.email}</div>
          <div className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20 inline-block">{user?.role || "user"}</div>
        </div>
      </div>

      {/* Edit form */}
      <div className="card p-8 mb-6">
        <h2 className="text-base font-semibold mb-6">Personal Information</h2>
        <form onSubmit={save} className="flex flex-col gap-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="input-group">
              <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Full Name</label>
              <input className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg focus:border-red-600 focus:ring-1 focus:ring-red-600" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="input-group">
              <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Email Address</label>
              <input className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg opacity-50 cursor-not-allowed" value={user?.email || ""} disabled />
            </div>
          </div>
          <div className="input-group">
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Role / Title</label>
            <input className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg focus:border-red-600 focus:ring-1 focus:ring-red-600" placeholder="e.g. Sales Manager, Founder, HR Lead…" />
          </div>
          <div className="input-group">
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Bio</label>
            <textarea className="input w-full p-4 text-sm bg-white/5 border border-white/10 rounded-lg focus:border-red-600 focus:ring-1 focus:ring-red-600 resize-y" rows={3} placeholder="Tell us a bit about your communication goals…" />
          </div>
          <div className="flex gap-3 items-center mt-2">
            <button type="submit" className="btn btn-primary h-9 px-4 text-sm font-medium" disabled={saving}>
              {saving ? <><span className="spinner w-4 h-4 border-t-white mr-2" /> Saving…</> : "Save Changes"}
            </button>
            {saved && <span className="text-green-400 text-sm font-medium flex items-center gap-1">✓ Saved successfully</span>}
          </div>
        </form>
      </div>

      {/* Danger zone */}
      <div className="card p-7 border border-red-500/20 bg-red-500/5">
        <h2 className="text-base font-semibold text-red-500 mb-2">Danger Zone</h2>
        <p className="text-sm font-normal text-white/50 leading-relaxed mb-5">
          Permanently delete your account and all associated training data. This cannot be undone.
        </p>
        <button className="btn btn-danger h-7 px-3 text-xs font-medium">Delete Account</button>
      </div>
    </div>
  );
}
