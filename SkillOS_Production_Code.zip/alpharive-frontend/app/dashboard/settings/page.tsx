"use client";
import { useState } from "react";

const TOGGLE_SETTINGS = [
  { id: "live_nudges", label: "Live Nudges", desc: "Show real-time alerts for filler words, pace, and volume during sessions." },
  { id: "voice_feedback", label: "AI Voice Responses", desc: "Have the AI persona speak its responses aloud during sessions." },
  { id: "auto_mic", label: "Auto-Start Microphone", desc: "Automatically request microphone access when a session begins." },
  { id: "email_summary", label: "Email Session Summary", desc: "Receive a detailed feedback report in your inbox after each session." },
];

const VOICE_OPTIONS = ["Default (Browser)", "Google US English", "Samantha (macOS)", "Synthesia"];
const SPEED_OPTIONS = ["Slow (0.85x)", "Normal (1.0x)", "Fast (1.15x)"];

export default function SettingsPage() {
  const [toggles, setToggles] = useState<Record<string, boolean>>({
    live_nudges: true, voice_feedback: true, auto_mic: false, email_summary: false,
  });
  const [voice, setVoice] = useState("Google US English");
  const [speed, setSpeed] = useState("Normal (1.0x)");
  const [filler_sensitivity, setFillerSensitivity] = useState(70);
  const [saved, setSaved] = useState(false);

  const toggle = (id: string) => setToggles((p) => ({ ...p, [id]: !p[id] }));

  const save = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="max-w-[760px] w-full">
      <div className="mb-8 space-y-1">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white/40 mb-3">
          <span>Account</span>
          <span>›</span>
          <span className="text-white/70">Settings</span>
        </div>
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-sm font-normal text-white/50 leading-relaxed">Customize your training experience.</p>
      </div>

      {/* Session preferences */}
      <div className="card p-8 mb-6">
        <h2 className="text-base font-semibold mb-6">Session Preferences</h2>
        <div className="flex flex-col">
          {TOGGLE_SETTINGS.map((s, i) => (
            <div key={s.id} className={`flex items-center justify-between py-4 ${i < TOGGLE_SETTINGS.length - 1 ? 'border-b border-white/10' : ''}`}>
              <div className="flex-1 pr-6">
                <div className="text-sm font-semibold mb-1">{s.label}</div>
                <div className="text-xs font-normal text-white/50">{s.desc}</div>
              </div>
              {/* Toggle */}
              <button
                onClick={() => toggle(s.id)}
                className={`w-11 h-6 rounded-full relative transition-colors flex-shrink-0 ${toggles[s.id] ? 'bg-gradient-to-r from-red-600 to-purple-600' : 'bg-white/10'}`}
              >
                <span className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all shadow-sm ${toggles[s.id] ? 'left-[22px]' : 'left-1'}`} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Voice settings */}
      <div className="card p-8 mb-6">
        <h2 className="text-base font-semibold mb-6">AI Voice Settings</h2>
        <div className="flex flex-col gap-5">
          <div className="input-group">
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">AI Voice</label>
            <select className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg focus:border-red-600 focus:ring-1 focus:ring-red-600 cursor-pointer" value={voice} onChange={(e) => setVoice(e.target.value)}>
              {VOICE_OPTIONS.map((v) => <option key={v} className="bg-black/90">{v}</option>)}
            </select>
          </div>
          <div className="input-group">
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Speaking Speed</label>
            <select className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg focus:border-red-600 focus:ring-1 focus:ring-red-600 cursor-pointer" value={speed} onChange={(e) => setSpeed(e.target.value)}>
              {SPEED_OPTIONS.map((s) => <option key={s} className="bg-black/90">{s}</option>)}
            </select>
          </div>
          <div className="input-group">
            <label className="flex justify-between items-end mb-2">
              <span className="block text-xs font-semibold text-white/50 uppercase tracking-wider">Filler Word Sensitivity</span>
              <span className="text-xs font-bold text-red-400">{filler_sensitivity}%</span>
            </label>
            <input
              type="range" min={0} max={100} value={filler_sensitivity}
              onChange={(e) => setFillerSensitivity(Number(e.target.value))}
              className="w-full accent-red-600 cursor-pointer h-1.5 bg-white/10 rounded-full appearance-none"
            />
            <div className="flex justify-between text-[10px] text-white/40 mt-2 uppercase tracking-wider font-semibold">
              <span>Relaxed (fewer alerts)</span>
              <span>Strict (more alerts)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Notifications */}
      <div className="card p-8 mb-6">
        <h2 className="text-base font-semibold mb-4">Notifications</h2>
        <p className="text-sm font-normal text-white/50 leading-relaxed mb-5">
          Notification preferences coming soon. You'll be able to control daily reminders, weekly summaries, and milestone alerts.
        </p>
        <div className="inline-block px-2 py-1 bg-white/5 border border-white/10 rounded text-[10px] font-bold text-white/40 uppercase tracking-wider">Coming Soon</div>
      </div>

      <div className="flex gap-3 items-center">
        <button className="btn btn-primary h-9 px-4 text-sm font-medium" onClick={save}>Save All Settings</button>
        {saved && <span className="text-green-400 text-sm font-medium flex items-center gap-1">✓ Settings saved</span>}
      </div>
    </div>
  );
}
