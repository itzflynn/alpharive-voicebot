"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { analyticsApi, scenariosApi, authApi } from "@/lib/api";
import type { AnalyticsSummary, Scenario } from "@/lib/types";
import { CATEGORY_EMOJI, DIFFICULTY_COLOR } from "@/lib/types";
import OnboardingModal from "@/components/OnboardingModal";

import { Flame, Target, BarChart2, Trophy, Film } from "lucide-react";

const SKILL_META: Record<string, { label: string; icon: string; color: string }> = {
  confidence: { label: "Confidence", icon: "💪", color: "#E50914" },
  clarity:    { label: "Clarity",    icon: "🔍", color: "#22d3ee" },
  tone:       { label: "Tone",       icon: "🎵", color: "#a78bfa" },
  persuasion: { label: "Persuasion", icon: "🎯", color: "#f59e0b" },
  filler_control: { label: "Filler Control", icon: "🤐", color: "#22c55e" },
};

export default function DashboardPage() {
  const [summary, setSummary] = useState<AnalyticsSummary | null>(null);
  const [skills, setSkills] = useState<Record<string, number>>({});
  const [recent, setRecent] = useState<any[]>([]);
  const [featured, setFeatured] = useState<Scenario[]>([]);
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);

  useEffect(() => {
    Promise.all([
      analyticsApi.summary(),
      analyticsApi.skills(),
      analyticsApi.recentSessions(),
      scenariosApi.list(),
      authApi.me(),
    ]).then(([s, sk, r, sc, u]) => {
      setSummary(s.data);
      setSkills(sk.data.skills || {});
      setRecent(r.data.sessions || []);
      setFeatured((sc.data as Scenario[]).slice(0, 3));
      setUser(u.data);
      // Show onboarding for first-time users
      if (!u.data.onboarding_completed && (s.data.sessions_completed === 0)) {
        setShowOnboarding(true);
      }
    }).finally(() => setLoading(false));
  }, []);

  const firstName = user?.full_name?.split(" ")[0] || "there";
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

  const STATS = [
    { label: "Sessions Completed", value: summary?.sessions_completed ?? 0, icon: Target, color: "var(--accent)" },
    { label: "Average Score", value: summary?.average_score ? `${summary.average_score}` : "—", icon: BarChart2, color: "#22d3ee" },
    { label: "Current Streak", value: `${summary?.streak_days ?? 0}d`, icon: Flame, color: "#f472b6" },
    { label: "Best Score", value: summary?.best_score ? `${summary.best_score}` : "—", icon: Trophy, color: "#f59e0b" },
    { label: "Scenarios Available", value: "10+", icon: Film, color: "#22c55e" },
  ];

  return (
    <div className="max-w-[1300px] w-full">
      {showOnboarding && <OnboardingModal onComplete={() => setShowOnboarding(false)} />}
      {/* Header */}
      <div className="mb-3 space-y-1">
        <p className="text-[10px] font-bold uppercase tracking-widest text-white/50">{greeting}, 👋</p>
        <h1 className="text-3xl font-bold">
          Welcome back, <span className="text-gradient">{firstName}</span>
        </h1>
        <p className="text-sm font-normal text-white/50 leading-relaxed">Track your progress and launch your next session.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
        {STATS.map((s) => (
          <div key={s.label} className="card card-premium p-5 flex flex-col justify-between">
            <div className="flex justify-between items-start mb-3">
              <div>
                <div className="text-3xl font-bold" style={{ color: s.color }}>
                  {loading ? <span className="skeleton w-16 h-8 block" /> : s.value}
                </div>
                <div className="text-xs text-white/50 font-medium mt-1">{s.label}</div>
              </div>
              <div className="w-9 h-9 rounded-lg flex items-center justify-center bg-white/5 flex-shrink-0" style={{ color: s.color }}>
                <s.icon size={20} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Middle row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-3">
        {/* Skill breakdown */}
        <div className="card p-6 md:col-span-2">
          <h2 className="text-lg font-semibold mb-3">Skill Breakdown</h2>
          <div className="space-y-4">
            {Object.entries(SKILL_META).map(([key, meta]) => {
              const score = skills[key] ?? 0;
              return (
                <div key={key}>
                  <div className="flex justify-between items-center mb-1 text-sm">
                    <span className="font-semibold flex items-center gap-2">{meta.icon} {meta.label}</span>
                    <span className="font-bold text-xs" style={{ color: score > 0 ? meta.color : "var(--text-muted)" }}>
                      {score > 0 ? `${Math.round(score)}/100` : "No data"}
                    </span>
                  </div>
                  <div className="progress-bar h-1.5">
                    <div className="progress-fill" style={{ width: `${score}%`, background: meta.color }} />
                  </div>
                </div>
              );
            })}
          </div>
          {Object.keys(skills).length === 0 && !loading && (
            <div className="text-center py-6 text-white/50 text-sm">
              <div className="text-2xl mb-2">🎯</div>
              Complete a session to see your skill scores.
            </div>
          )}
        </div>

        {/* Quick start */}
        <div className="card p-6 flex flex-col gap-4">
          <div>
            <h2 className="text-lg font-semibold mb-1">Quick Start</h2>
            <p className="text-sm font-normal text-white/50 leading-relaxed">
              Jump into a scenario and start training immediately.
            </p>
          </div>
          <Link href="/scenarios" className="btn btn-primary w-full h-9 px-4 text-sm font-medium">
            Browse All Scenarios →
          </Link>
          <div className="divider my-2" />
          <div className="text-[10px] font-bold uppercase tracking-widest text-white/50">
            Suggested
          </div>
          {featured.map((s) => (
            <Link href={`/scenarios/${s.id}`} key={s.id} className="card p-4 flex gap-3 items-center">
              <span className="text-xl flex-shrink-0">{CATEGORY_EMOJI[s.category] || "🎭"}</span>
              <div className="min-w-0">
                <div className="text-sm font-semibold truncate">
                  {s.title}
                </div>
                <div className="text-xs text-white/50 font-medium mt-1">
                  {s.duration_minutes} min · {s.difficulty}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Recent sessions */}
      <div className="card p-6">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/5">
          <h2 className="text-lg font-semibold">Recent Sessions</h2>
          <Link href="/sessions" className="text-xs font-bold uppercase tracking-widest text-white/50 hover:text-white transition">View all</Link>
        </div>

        {recent.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center">
              <span className="text-2xl">🎭</span>
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-semibold">No Sessions Yet</h3>
              <p className="text-sm text-white/40 max-w-sm">Start your first training scenario to see your history.</p>
            </div>
            <Link href="/scenarios" className="btn btn-primary h-9 px-4 text-sm font-medium">Browse Scenarios</Link>
          </div>
        ) : (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Scenario</th>
                  <th>Date</th>
                  <th>Duration</th>
                  <th>Score</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((s) => {
                  const score = s.overall_score;
                  const scoreColor = score >= 70 ? "var(--success)" : score >= 50 ? "var(--warning)" : "var(--danger)";
                  return (
                    <tr key={s.session_id}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <span className="text-xl">{CATEGORY_EMOJI[s.category] || "🎯"}</span>
                          <span className="text-sm font-semibold">{s.scenario_title || "—"}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm font-normal text-white/70">
                        {s.completed_at ? new Date(s.completed_at).toLocaleDateString("en-IN", { day: "numeric", month: "short" }) : "—"}
                      </td>
                      <td className="px-4 py-3 text-sm font-normal text-white/70">
                        {s.duration_seconds ? `${Math.round(s.duration_seconds / 60)}m` : "—"}
                      </td>
                      <td className="px-4 py-3">
                        {score != null ? (
                          <span className="text-base font-bold" style={{ color: scoreColor }}>
                            {Math.round(score)}
                          </span>
                        ) : <span className="text-sm font-normal text-white/30">—</span>}
                      </td>
                      <td className="px-4 py-3">
                        <Link href={`/sessions/${s.session_id}/feedback`} className="btn btn-ghost h-7 px-3 text-xs font-medium">
                          View →
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
