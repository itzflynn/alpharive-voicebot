"use client";
import { useState } from "react";
import { api } from "@/lib/api";

export default function BotPage() {
  const [url, setUrl] = useState("");
  const [botName, setBotName] = useState("SkillOS Notetaker");
  const [loading, setLoading] = useState(false);
  const [deployedBot, setDeployedBot] = useState<any>(null);
  const [error, setError] = useState("");

  const deployBot = async () => {
    if (!url) {
      setError("Please enter a valid meeting URL");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const { data } = await api.post("/bot/deploy", { meeting_url: url, bot_name: botName });
      setDeployedBot(data);
      setUrl("");
    } catch (e) {
      setError("Failed to deploy bot.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 700, margin: "0 auto", padding: "40px 0" }}>
      <h1 className="heading-lg" style={{ marginBottom: 12 }}>🤖 Meeting Bot Integration</h1>
      <p style={{ color: "var(--text-secondary)", marginBottom: 40, lineHeight: 1.6 }}>
        Deploy the SkillOS bot to join your live Zoom, Microsoft Teams, or Google Meet calls.
        The bot will record the session and generate a full communication report afterwards.
      </p>

      <div className="card p-6" style={{ marginBottom: 32 }}>
        <h2 className="text-lg font-semibold mb-4">Deploy New Bot</h2>
        
        {error && <div className="text-red-500 mb-4 text-sm">{error}</div>}
        
        <div style={{ marginBottom: 16 }}>
          <label style={{ display: "block", marginBottom: 8, fontSize: "0.85rem", color: "var(--text-secondary)" }}>Meeting URL (Zoom, Meet, Teams)</label>
          <input 
            type="text" 
            className="input w-full" 
            placeholder="https://zoom.us/j/123456789"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />
        </div>
        
        <div style={{ marginBottom: 24 }}>
          <label style={{ display: "block", marginBottom: 8, fontSize: "0.85rem", color: "var(--text-secondary)" }}>Bot Display Name</label>
          <input 
            type="text" 
            className="input w-full" 
            value={botName}
            onChange={(e) => setBotName(e.target.value)}
          />
        </div>
        
        <button 
          className="btn btn-primary w-full flex items-center justify-center gap-2"
          onClick={deployBot}
          disabled={loading}
        >
          {loading ? <span className="spinner w-4 h-4" /> : "Deploy Bot to Meeting"}
        </button>
      </div>

      {deployedBot && (
        <div className="card p-6" style={{ border: "1px solid var(--success)" }}>
          <div className="flex items-center gap-3 mb-4">
            <span className="text-2xl">✅</span>
            <div>
              <h3 className="font-semibold text-success">Bot Deployment Initiated</h3>
              <p className="text-xs text-white/50">ID: {deployedBot.id}</p>
            </div>
          </div>
          <p className="text-sm text-white/70">
            The bot "{deployedBot.bot_name}" is currently spinning up infrastructure and will join your {deployedBot.platform} meeting shortly.
          </p>
        </div>
      )}
    </div>
  );
}
