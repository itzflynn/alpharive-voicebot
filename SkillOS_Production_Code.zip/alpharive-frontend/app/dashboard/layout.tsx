"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { authApi } from "@/lib/api";
import type { User } from "@/lib/types";
import Logo from "@/components/Logo";

import { LayoutDashboard, Film, PenSquare, ClipboardList, BarChart2, User as UserIcon, Settings, Video } from "lucide-react";

const NAV = [
  { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/scenarios", icon: Film, label: "Scenarios" },
  { href: "/scenarios/create", icon: PenSquare, label: "Create Scenario" },
  { href: "/sessions", icon: ClipboardList, label: "My Sessions" },
  { href: "/analytics", icon: BarChart2, label: "Analytics" },
];

const NAV_BOTTOM = [
  { href: "/dashboard/bot", icon: Video, label: "Meeting Bots" },
  { href: "/dashboard/profile", icon: UserIcon, label: "Profile" },
  { href: "/dashboard/settings", icon: Settings, label: "Settings" },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    authApi.me().then((r) => setUser(r.data)).catch(() => router.push("/login"));
  }, []);

  const signOut = () => {
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    router.push("/");
  };

  const initials = user ? user.full_name?.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2) || "U" : "…";

  return (
    <div className="layout">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="h-14 flex items-center px-4 border-b border-white/5">
          <Logo />
        </div>

        <nav className="sidebar-nav">
          <div className="sidebar-section-label">Main</div>
          {NAV.map((n) => (
            <Link key={n.href} href={n.href}
              className={`nav-item ${pathname === n.href || (n.href !== "/dashboard" && pathname.startsWith(n.href)) ? "active" : ""}`}>
              <span className="nav-icon"><n.icon size={18} /></span>
              {n.label}
            </Link>
          ))}

          <div className="sidebar-section-label mt-4">Account</div>
          {NAV_BOTTOM.map((n) => (
            <Link key={n.href} href={n.href}
              className={`nav-item ${pathname === n.href ? "active" : ""}`}>
              <span className="nav-icon"><n.icon size={18} /></span>
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-user">
            <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-xs font-bold text-white flex-shrink-0 object-cover">{initials}</div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold truncate">
                {user?.full_name || "Loading…"}
              </div>
              <div className="text-[11px] font-normal text-white/50">{user?.role || ""}</div>
            </div>
          </div>
          <button onClick={signOut} className="btn btn-ghost h-7 px-3 text-xs font-medium w-full mt-2 justify-start gap-2 text-white/50 hover:text-white">
            <span>↩</span> Sign Out
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="main-content">
        {children}
      </main>
    </div>
  );
}
