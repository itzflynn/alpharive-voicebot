"use client";
import { useEffect, useState } from "react";
import { analyticsApi } from "@/lib/api";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from "recharts";

const SKILLS = ["confidence", "clarity", "tone", "persuasion", "filler_control"];
const SKILL_LABELS: Record<string, string> = {
  confidence: "Confidence 💪",
  clarity: "Clarity 🔍",
  tone: "Tone 🎵",
  persuasion: "Persuasion 🎯",
  filler_control: "Filler Control 🤐",
};

const SKILL_COLORS: Record<string, string> = {
  overall_score: "#E50914",
  confidence: "#f59e0b",
  clarity: "#22d3ee",
  tone: "#a78bfa",
  persuasion: "#fb923c",
  filler_control: "#22c55e",
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: "rgba(15,15,15,0.95)", border: "1px solid rgba(255,255,255,0.12)",
      borderRadius: 12, padding: "12px 16px", backdropFilter: "blur(12px)",
    }}>
      <p style={{ fontSize: "0.8rem", color: "var(--text-muted)", marginBottom: 8 }}>{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
          <div style={{ width: 8, height: 8, borderRadius: "50%", background: p.color }} />
          <span style={{ fontSize: "0.82rem", color: "var(--text-secondary)" }}>
            {p.name}: <strong style={{ color: p.color }}>{p.value}</strong>
          </span>
        </div>
      ))}
    </div>
  );
};

export default function AnalyticsPage() {
  const [summary, setSummary] = useState<any>(null);
  const [skills, setSkills] = useState<Record<string, number>>({});
  const [scoreHistory, setScoreHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeLines, setActiveLines] = useState<Record<string, boolean>>({
    overall_score: true,
    confidence: false,
    clarity: false,
    tone: false,
    persuasion: false,
    filler_control: false,
  });

  useEffect(() => {
    Promise.all([
      analyticsApi.summary(),
      analyticsApi.skills(),
      analyticsApi.scoreHistory(),
    ]).then(([sum, sk, hist]) => {
      setSummary(sum.data);
      setSkills(sk.data.skills || {});
      setScoreHistory(hist.data.history || []);
    }).finally(() => setLoading(false));
  }, []);

  const toggleLine = (key: string) => {
    setActiveLines((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="max-w-[1000px] w-full">
      <h1 className="text-3xl font-bold mb-2">Analytics</h1>
      <p className="text-sm font-normal text-white/50 leading-relaxed mb-8">Track your skill progression over time.</p>

      {/* Summary stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Sessions Completed", value: summary?.sessions_completed ?? 0, icon: "🎯", color: "var(--accent)" },
          { label: "Average Score", value: summary?.average_score ?? 0, icon: "📊", color: "#22d3ee" },
          { label: "Best Score", value: summary?.best_score ?? 0, icon: "🏆", color: "#f59e0b" },
          { label: "Current Streak", value: `${summary?.streak_days ?? 0}d`, icon: "🔥", color: "#f472b6" },
          { label: "Longest Streak", value: `${summary?.longest_streak ?? 0}d`, icon: "🏅", color: "#a78bfa" },
        ].map((s) => (
          <div key={s.label} className="card p-5 flex flex-col justify-between">
            <div className="flex justify-between items-start mb-3">
              <div>
                <div className="text-3xl font-bold" style={{ color: s.color }}>{loading ? <span className="skeleton w-16 h-8 block" /> : s.value}</div>
                <div className="text-xs text-white/50 font-medium mt-1">{s.label}</div>
              </div>
              <div className="text-2xl">{s.icon}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Score Trend Chart */}
      <div className="card p-6 mb-6">
        <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-3">
          <h2 className="text-base font-semibold">Score Trend (Last 30 Days)</h2>
          <div className="text-xs font-medium text-white/50 uppercase tracking-wider">
            Click a metric below to toggle it
          </div>
        </div>

        {/* Toggle buttons */}
        <div className="flex flex-wrap gap-2 mb-5">
          {Object.keys(SKILL_COLORS).map((key) => (
            <button key={key} onClick={() => toggleLine(key)}
              style={{
                padding: "5px 14px", borderRadius: 20, border: `1px solid ${SKILL_COLORS[key]}`,
                background: activeLines[key] ? SKILL_COLORS[key] + "22" : "transparent",
                color: activeLines[key] ? SKILL_COLORS[key] : "var(--text-muted)",
                fontSize: "0.78rem", fontWeight: activeLines[key] ? 700 : 400,
                cursor: "pointer", transition: "all 0.2s",
              }}>
              {key === "overall_score" ? "Overall" : SKILL_LABELS[key]?.replace(/ .+/, "")}
            </button>
          ))}
        </div>

        {scoreHistory.length > 0 ? (
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={scoreHistory} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="date" tick={{ fill: "var(--text-muted)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis domain={[0, 100]} tick={{ fill: "var(--text-muted)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              {Object.keys(SKILL_COLORS).map((key) =>
                activeLines[key] ? (
                  <Line key={key} type="monotone" dataKey={key}
                    name={key === "overall_score" ? "Overall" : SKILL_LABELS[key]?.replace(/ .+/, "")}
                    stroke={SKILL_COLORS[key]} strokeWidth={key === "overall_score" ? 2.5 : 1.5}
                    dot={{ r: 4, fill: SKILL_COLORS[key], strokeWidth: 0 }}
                    activeDot={{ r: 6 }}
                    connectNulls
                  />
                ) : null
              )}
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex flex-col items-center justify-center py-24 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center">
              <span className="text-2xl text-white/20">📈</span>
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-semibold">No Data Yet</h3>
              <p className="text-sm text-white/40 max-w-sm">Complete sessions to see your score trend here.</p>
            </div>
          </div>
        )}
      </div>

      {/* Current Skill Levels */}
      <div className="card p-6 mb-6">
        <h2 className="text-base font-semibold mb-5 pb-3 border-b border-white/5">Current Skill Levels</h2>
        <div className="space-y-4">
          {SKILLS.map((skill) => {
            const score = skills[skill] ?? 0;
            const color = score >= 70 ? "var(--success)" : score >= 50 ? "var(--warning)" : score > 0 ? "var(--danger)" : "var(--text-muted)";
            return (
              <div key={skill}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-semibold">{SKILL_LABELS[skill]}</span>
                  <span className="text-xs font-bold" style={{ color }}>
                    {score > 0 ? `${score}/100` : "No data yet"}
                  </span>
                </div>
                <div className="progress-bar h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-700 ease-out" style={{ width: `${score}%`, background: SKILL_COLORS[skill] }} />
                </div>
              </div>
            );
          })}
        </div>
        {Object.keys(skills).length === 0 && !loading && (
          <div className="text-center py-6 text-sm text-white/50">
            Complete a session to see your skill breakdown.
          </div>
        )}
      </div>
    </div>
  );
}
