"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { authApi } from "@/lib/api";
import Logo from "@/components/Logo";

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const { data } = await authApi.login(form);
      localStorage.setItem("access_token", data.access_token);
      localStorage.setItem("refresh_token", data.refresh_token);
      router.push("/dashboard");
    } catch (err: any) {
      let msg = "Invalid credentials";
      if (err.response?.data?.detail) {
        if (typeof err.response.data.detail === "string") {
          msg = err.response.data.detail;
        } else if (Array.isArray(err.response.data.detail)) {
          msg = err.response.data.detail.map((d: any) => `${d.loc?.[d.loc?.length - 1]}: ${d.msg}`).join(", ");
        }
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "24px" }}>
      <div style={{ position: "fixed", top: "20%", left: "20%", width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle, rgba(229,9,20,0.12) 0%, transparent 70%)", filter: "blur(80px)", pointerEvents: "none" }} />
      <div className="card w-full max-w-[440px] p-10 md:p-12">
        <Link href="/" className="inline-block mb-8">
          <Logo />
        </Link>
        <h1 className="text-3xl font-bold mb-2">Welcome back</h1>
        <p className="text-sm font-normal text-white/50 leading-relaxed mb-8">Sign in to continue your training.</p>

        <form onSubmit={submit} className="flex flex-col gap-5">
          <div className="input-group">
            <label htmlFor="email" className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Email</label>
            <input id="email" type="email" className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg placeholder:text-white/30 focus:border-red-600 focus:ring-1 focus:ring-red-600" placeholder="you@company.com" value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })} required />
          </div>
          <div className="input-group">
            <label htmlFor="password" className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Password</label>
            <input id="password" type="password" className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg placeholder:text-white/30 focus:border-red-600 focus:ring-1 focus:ring-red-600" placeholder="••••••••" value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })} required />
          </div>
          {error && <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/30 p-3 rounded-lg">{error}</p>}
          <button id="login-btn" type="submit" className="btn btn-primary h-11 px-6 text-base font-semibold w-full mt-2" disabled={loading}>
            {loading ? <span className="spinner w-5 h-5 border-t-white" /> : "Sign In →"}
          </button>
        </form>

        <p className="text-center mt-8 text-sm text-white/50">
          No account? <Link href="/register" className="text-red-400 font-semibold hover:text-red-300">Create one free</Link>
        </p>
      </div>
    </main>
  );
}
