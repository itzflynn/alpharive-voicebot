"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { sessionsApi, api } from "@/lib/api";
import type { Feedback } from "@/lib/types";

const DIMS = [
  { key: "confidence_score", label: "Confidence", icon: "💪", color: "#E50914" },
  { key: "clarity_score", label: "Clarity", icon: "🔍", color: "#22d3ee" },
  { key: "tone_score", label: "Tone", icon: "🎵", color: "#a78bfa" },
  { key: "persuasion_score", label: "Persuasion", icon: "🎯", color: "#f59e0b" },
  { key: "filler_control_score", label: "Filler Control", icon: "🤐", color: "#22c55e" },
];

function ScoreCircle({ score }: { score: number }) {
  const color = score >= 70 ? "#10b981" : score >= 50 ? "#f59e0b" : "#ef4444";
  const r = 54, circ = 2 * Math.PI * r;
  const dash = circ * (score / 100);
  return (
    <div className="relative inline-flex items-center justify-center w-[140px] h-[140px]">
      <svg width="140" height="140" style={{ transform: "rotate(-90deg)" }}>
        <circle cx="70" cy="70" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="10" />
        <circle cx="70" cy="70" r={r} fill="none" stroke={color} strokeWidth="10"
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
          style={{ transition: "stroke-dasharray 1s ease" }} />
      </svg>
      <div className="absolute flex items-baseline">
        <span className="text-4xl font-bold" style={{ color }}>{Math.round(score)}</span>
        <span className="text-lg font-normal text-white/30 ml-1">/ 100</span>
      </div>
    </div>
  );
}

function MetricBar({ label, value, max = 100, color = "var(--accent)" }: { label: string; value: number; max?: number; color?: string }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.82rem", marginBottom: 5 }}>
        <span style={{ color: "var(--text-secondary)" }}>{label}</span>
        <span style={{ fontWeight: 700, color }}>{Math.round(value)}{max === 100 ? "" : ""}</span>
      </div>
      <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-700 ease-out" style={{ width: `${Math.min((value / max) * 100, 100)}%`, background: color }} />
      </div>
    </div>
  );
}

export default function FeedbackPage() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const router = useRouter();
  const [fb, setFb] = useState<Feedback | null>(null);
  const [loading, setLoading] = useState(true);
  const [retries, setRetries] = useState(0);
  const [shareStatus, setShareStatus] = useState<"idle" | "loading" | "copied">("idle");
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [recordingUrl, setRecordingUrl] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await sessionsApi.feedback(sessionId);
        setFb(data);
        setLoading(false);
      } catch {
        if (retries < 8) setTimeout(() => setRetries((r) => r + 1), 1500);
        else setLoading(false);
      }
    };
    load();
  }, [sessionId, retries]);

  // Check for recording
  useEffect(() => {
    api.head(`/sessions/${sessionId}/recording`)
      .then(() => setRecordingUrl(`${process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"}/sessions/${sessionId}/recording`))
      .catch(() => { });
  }, [sessionId]);

  const handleShare = async () => {
    setShareStatus("loading");
    try {
      const { data } = await api.post(`/sessions/${sessionId}/share`);
      const url = `${window.location.origin}/share/${data.share_token}`;
      setShareUrl(url);
      await navigator.clipboard.writeText(url);
      setShareStatus("copied");
      setTimeout(() => setShareStatus("idle"), 3000);
    } catch {
      setShareStatus("idle");
    }
  };

  if (loading) return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "60vh", gap: 16 }}>
      <div className="spinner" style={{ width: 48, height: 48 }} />
      <p style={{ color: "var(--text-secondary)" }}>SkillOS is evaluating your session...</p>
    </div>
  );

  if (!fb) return (
    <div style={{ textAlign: "center", padding: "80px 0" }}>
      <p style={{ color: "var(--danger)" }}>Could not load feedback. <button className="btn btn-ghost" onClick={() => router.back()}>Go back</button></p>
    </div>
  );

  const vocab = (fb as any).vocabulary_analysis;

  return (
    <div style={{ maxWidth: 900 }}>
      <div className="flex items-center justify-between" style={{ marginBottom: 32 }}>
        <div>
          <h1 className="heading-lg">Session Feedback</h1>
          <p style={{ color: "var(--text-secondary)", marginTop: 4 }}>AI-powered evaluation by SkillOS's Communication Intelligence Engine.</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button
            onClick={handleShare}
            className={`btn ${shareStatus === "copied" ? "btn-secondary" : "btn-ghost"} btn-sm`}
            disabled={shareStatus === "loading"}
          >
            {shareStatus === "loading" ? <span className="spinner" style={{ width: 14, height: 14 }} /> :
              shareStatus === "copied" ? "✓ Link Copied!" : "🔗 Share Results"}
          </button>
          <Link href="/scenarios" className="btn btn-secondary btn-sm">Practice Again →</Link>
        </div>
      </div>

      {/* Overall score */}
      <div className="card card-glow flex items-center gap-12 p-6 mb-6" style={{ background: "var(--gradient-subtle)" }}>
        <div className="text-center flex-shrink-0">
          <ScoreCircle score={fb.overall_score} />
          <p className="text-xs font-medium text-white/50 uppercase tracking-wider mt-2">Overall Score</p>
        </div>
        <div>
          <h2 className="text-xl font-semibold mb-3">
            {fb.overall_score >= 80 ? "🏆 Excellent Performance" : fb.overall_score >= 60 ? "📈 Good Progress" : "💪 Keep Practicing"}
          </h2>
          <p className="text-sm leading-loose text-white/70">{fb.detailed_feedback}</p>
        </div>
      </div>

      {/* Dimension scores */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        {DIMS.map((d) => {
          const score = (fb as any)[d.key] ?? 0;
          const color = score >= 70 ? "var(--success)" : score >= 50 ? "var(--warning)" : "var(--danger)";
          return (
            <div key={d.key} className="card p-5 text-center">
              <div className="text-2xl mb-2">{d.icon}</div>
              <div className="text-2xl font-bold" style={{ color }}>{Math.round(score)}</div>
              <div className="text-xs font-medium text-white/50 uppercase tracking-wider mt-1">{d.label}</div>
              <div className="progress-bar h-1.5 mt-3">
                <div className="progress-fill" style={{ width: `${score}%`, background: d.color }} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Pacing + Filler */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-6">
        {fb.pacing_wpm !== undefined && fb.pacing_wpm !== null && (
          <div className="card p-6">
            <h3 className="text-base font-semibold mb-3">⏱️ Pacing Analysis</h3>
            <div className="flex items-baseline gap-3">
              <span className="text-4xl font-bold" style={{ color: fb.pacing_wpm > 160 ? "var(--warning)" : fb.pacing_wpm < 110 ? "var(--danger)" : "var(--success)" }}>
                {fb.pacing_wpm}
              </span>
              <span className="text-sm font-medium text-white/50 uppercase tracking-wider">Words Per Minute</span>
            </div>
            <p className="text-sm leading-loose text-white/70 mt-2">
              {fb.pacing_wpm > 160 ? "Speaking a bit fast — slow down for clarity." : fb.pacing_wpm < 110 ? "Speaking slowly — pick up the pace for engagement." : "Your pacing is excellent (120–150 WPM is ideal)."}
            </p>
          </div>
        )}
        {fb.filler_word_count > 0 && (
          <div className="card p-6" style={{ background: "rgba(245,158,11,0.06)", borderColor: "rgba(245,158,11,0.2)" }}>
            <h3 className="text-base font-semibold text-warning mb-3">🤐 Filler Words: {fb.filler_word_count}</h3>
            <div className="flex flex-wrap gap-2 mt-3">
              {fb.filler_words.map((w) => <span key={w} className="badge badge-yellow">"{w}"</span>)}
            </div>
            <p className="text-sm leading-loose text-warning/70 mt-3">Use the Live Nudges feature to train yourself to pause silently instead.</p>
          </div>
        )}
      </div>

      {/* Body Language / CV Analysis */}
      {(fb.eye_contact_score !== undefined && fb.eye_contact_score !== null || fb.smile_score !== undefined && fb.smile_score !== null) && (
        <div className="card" style={{ padding: "28px", marginBottom: 24 }}>
          <h3 className="heading-sm" style={{ marginBottom: 20 }}>👁️ Body Language Analysis</h3>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
            {fb.eye_contact_score !== undefined && fb.eye_contact_score !== null && (
              <div>
                <MetricBar label="Eye Contact Ratio" value={fb.eye_contact_score} color="#22d3ee" />
                <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", marginTop: 8 }}>
                  {fb.eye_contact_score > 70 ? "Great job maintaining eye contact with the camera!" : "Try to look directly at the camera more often to build connection."}
                </p>
              </div>
            )}
            {fb.smile_score !== undefined && fb.smile_score !== null && (
              <div>
                <MetricBar label="Smile / Engagement" value={fb.smile_score} color="#f59e0b" />
                <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", marginTop: 8 }}>
                  {fb.smile_score > 40 ? "You looked very engaged and positive!" : "Remember to smile occasionally to project warmth and confidence."}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Vocabulary Analysis Card */}
      {vocab && (
        <div className="card" style={{ padding: "28px", marginBottom: 24 }}>
          <h3 className="heading-sm" style={{ marginBottom: 20 }}>📚 Vocabulary Analysis</h3>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
            <div>
              <MetricBar label="Vocabulary Score" value={vocab.vocabulary_score} color="var(--accent)" />
              <MetricBar label="Word Diversity" value={vocab.vocabulary_diversity} color="#22d3ee" />
              <MetricBar label="Avg Sentence Length" value={vocab.avg_sentence_length} max={30} color="#a78bfa" />
              <MetricBar label="Question Ratio (%)" value={vocab.question_ratio} color="#f59e0b" />
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <div style={{ fontSize: "0.75rem", color: "var(--success)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 8 }}>
                  ✅ Power Words Used ({vocab.power_word_count})
                </div>
                {vocab.power_words_used.length > 0 ? (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                    {vocab.power_words_used.map((w: string) => (
                      <span key={w} style={{ background: "rgba(34,197,94,0.12)", border: "1px solid rgba(34,197,94,0.3)", color: "#22c55e", padding: "2px 10px", borderRadius: 20, fontSize: "0.78rem", fontWeight: 600 }}>
                        {w}
                      </span>
                    ))}
                  </div>
                ) : <p style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>None detected — try using words like "leverage", "drive", "impact".</p>}
              </div>
              <div>
                <div style={{ fontSize: "0.75rem", color: "var(--warning)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 8 }}>
                  ⚠️ Weak/Hedge Words ({vocab.weak_word_count})
                </div>
                {vocab.weak_words_used.length > 0 ? (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                    {vocab.weak_words_used.map((w: string) => (
                      <span key={w} style={{ background: "rgba(245,158,11,0.12)", border: "1px solid rgba(245,158,11,0.3)", color: "#f59e0b", padding: "2px 10px", borderRadius: 20, fontSize: "0.78rem", fontWeight: 600 }}>
                        {w}
                      </span>
                    ))}
                  </div>
                ) : <p style={{ fontSize: "0.8rem", color: "var(--success)" }}>None detected. Excellent!</p>}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Pronunciation Card */}
      {fb.pronunciation_score !== undefined && fb.pronunciation_score !== null && (
        <div className="card" style={{ padding: "28px", marginBottom: 24, borderLeft: "4px solid #8b5cf6" }}>
          <div className="flex items-start gap-4">
            <div className="text-4xl">🗣️</div>
            <div className="flex-1">
              <h3 className="heading-sm" style={{ marginBottom: 8 }}>Pronunciation & Articulation</h3>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
                <span style={{ fontSize: "2rem", fontWeight: 700, color: fb.pronunciation_score >= 80 ? "var(--success)" : "var(--warning)" }}>
                  {Math.round(fb.pronunciation_score)}<span style={{ fontSize: "1rem", color: "var(--text-muted)" }}>/100</span>
                </span>
                <div style={{ height: 6, flex: 1, background: "rgba(255,255,255,0.05)", borderRadius: 10, overflow: "hidden" }}>
                  <div style={{ width: `${fb.pronunciation_score}%`, height: "100%", background: fb.pronunciation_score >= 80 ? "var(--success)" : "var(--warning)", borderRadius: 10 }} />
                </div>
              </div>
              <p style={{ fontSize: "0.9rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>{fb.pronunciation_feedback}</p>
            </div>
          </div>
        </div>
      )}

      {/* Video Recording Playback */}
      {recordingUrl && (
        <div className="card" style={{ padding: "28px", marginBottom: 24 }}>
          <h3 className="heading-sm" style={{ marginBottom: 16 }}>🎥 Your Session Recording</h3>
          <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", marginBottom: 16 }}>Review your recording to observe your body language and delivery.</p>
          <video
            src={recordingUrl}
            controls
            style={{ width: "100%", borderRadius: 12, background: "#000", maxHeight: 400 }}
          />
        </div>
      )}

      {/* Rephrasing suggestions */}
      {fb.rephrasing_suggestions && fb.rephrasing_suggestions.length > 0 && (
        <div className="card" style={{ padding: "28px", marginBottom: 24 }}>
          <h3 className="heading-sm" style={{ marginBottom: 20 }}>✍️ AI Rephrasing Suggestions</h3>
          <p style={{ fontSize: "0.9rem", color: "var(--text-secondary)", marginBottom: 20 }}>SkillOS found opportunities to make your delivery more impactful.</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {fb.rephrasing_suggestions.map((r: any, i: number) => (
              <div key={i} style={{ padding: "16px", background: "rgba(255,255,255,0.03)", borderRadius: 12, border: "1px solid rgba(255,255,255,0.08)" }}>
                <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
                  <span style={{ fontSize: "1.2rem" }}>❌</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "0.75rem", color: "var(--danger)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>You Said</div>
                    <div style={{ fontSize: "0.95rem", color: "var(--text-secondary)", fontStyle: "italic" }}>"{r.original}"</div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 12 }}>
                  <span style={{ fontSize: "1.2rem" }}>✨</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "0.75rem", color: "var(--success)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>Better Alternative</div>
                    <div style={{ fontSize: "0.95rem", color: "var(--text-primary)", fontWeight: 500 }}>"{r.improved}"</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Strengths + Improvements */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-6">
        <div className="card p-6">
          <h3 className="text-base font-semibold text-success mb-4">✅ Strengths</h3>
          <ul className="flex flex-col gap-3">
            {fb.strengths.map((s, i) => (
              <li key={i} className="text-sm leading-relaxed text-white/70 flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full inline-block flex-shrink-0 mt-2 bg-success"></span>
                <span>{s}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="card p-6">
          <h3 className="text-base font-semibold text-warning mb-4">🚀 Areas to Improve</h3>
          <ul className="flex flex-col gap-3">
            {fb.improvements.map((s, i) => (
              <li key={i} className="text-sm leading-relaxed text-white/70 flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full inline-block flex-shrink-0 mt-2 bg-warning"></span>
                <span>{s}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Improvement Plan */}
      {fb.improvement_plan && (
        <div className="card p-6 mb-6">
          <h3 className="text-base font-semibold mb-5">🗓 Your Improvement Plan</h3>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
            {[
              { label: "This Week", value: fb.improvement_plan.this_week, color: "var(--accent)" },
              { label: "This Month", value: fb.improvement_plan.this_month, color: "#a78bfa" },
              { label: "Long Term", value: fb.improvement_plan.long_term, color: "var(--success)" },
            ].map((p) => (
              <div key={p.label} className="card" style={{ padding: "16px 18px", borderColor: `${p.color}33` }}>
                <div style={{ fontSize: "0.72rem", fontWeight: 700, color: p.color, marginBottom: 8, letterSpacing: "0.06em", textTransform: "uppercase" }}>{p.label}</div>
                <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>{p.value}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex gap-4">
        <Link href="/scenarios" className="btn btn-primary btn-lg" style={{ flex: 1, justifyContent: "center" }}>🎭 Practice Another Scenario</Link>
        <Link href="/dashboard" className="btn btn-secondary" style={{ flex: 1, justifyContent: "center" }}>📊 View Dashboard</Link>
      </div>
    </div>
  );
}
