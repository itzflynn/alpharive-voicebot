"use client";
import { useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { sessionsApi, api } from "@/lib/api";
import WaveformVisualizer from "@/components/WaveformVisualizer";

import { Mic, Send, Square, Video, MicOff } from "lucide-react";

interface Message { role: "user" | "ai"; text: string; }
interface Nudge { type: "filler" | "pace" | "volume"; message: string; id: number }

export default function SessionPage() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const router = useRouter();
  const [sessionData, setSessionData] = useState<any>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [elapsed, setElapsed] = useState(0);
  const [completing, setCompleting] = useState(false);
  const [started, setStarted] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [nudge, setNudge] = useState<Nudge | null>(null);
  const [volume, setVolume] = useState(0);
  const [analyserNode, setAnalyserNode] = useState<AnalyserNode | null>(null);

  // Webcam recording
  const [webcamEnabled, setWebcamEnabled] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const videoPreviewRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const webcamStreamRef = useRef<MediaStream | null>(null);
  const chunkIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const chunkBufferRef = useRef<Blob[]>([]);

  const chatRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const startedAt = useRef(Date.now());
  const recognitionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number>(0);
  const wordCountRef = useRef(0);
  const isListeningRef = useRef(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    sessionsApi.get(sessionId as string).then((r) => setSessionData(r.data));
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      const loadVoices = () => setVoices(window.speechSynthesis.getVoices());
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
    return () => stopListening();
  }, [sessionId]);

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages]);

  const showNudge = (type: "filler" | "pace" | "volume", message: string) => {
    setNudge({ type, message, id: Date.now() });
    setTimeout(() => setNudge(null), 3500);
  };

  // ── Webcam ─────────────────────────────────────────────────────────────────

  const startWebcam = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      webcamStreamRef.current = stream;
      if (videoPreviewRef.current) {
        videoPreviewRef.current.srcObject = stream;
        videoPreviewRef.current.muted = true;
      }
      return stream;
    } catch (err) {
      console.error("Webcam error:", err);
      setWebcamEnabled(false);
      return null;
    }
  };

  const startWebcamRecording = async (audioStream: MediaStream) => {
    const videoStream = await startWebcam();
    if (!videoStream) return;

    // Combine audio + video tracks
    const combinedStream = new MediaStream([
      ...videoStream.getVideoTracks(),
      ...audioStream.getAudioTracks(),
    ]);

    const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp9")
      ? "video/webm;codecs=vp9"
      : "video/webm";

    const recorder = new MediaRecorder(combinedStream, { mimeType });
    mediaRecorderRef.current = recorder;
    recorder.start();
    setIsRecording(true);

    // Send a chunk every 5 seconds
    chunkIntervalRef.current = setInterval(async () => {
      if (recorder.state === "recording") {
        recorder.requestData();
      }
    }, 5000);

    recorder.ondataavailable = async (e) => {
      if (e.data && e.data.size > 0) {
        try {
          await api.post(
            `/sessions/${sessionId}/recording/chunk`,
            e.data,
            { headers: { "Content-Type": "video/webm" } }
          );
        } catch (err) {
          console.error("Recording chunk upload failed:", err);
        }
      }
    };
  };

  const stopWebcamRecording = async () => {
    if (chunkIntervalRef.current) clearInterval(chunkIntervalRef.current);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
    if (webcamStreamRef.current) {
      webcamStreamRef.current.getTracks().forEach((t) => t.stop());
    }
    setIsRecording(false);
    try {
      await api.post(`/sessions/${sessionId}/recording/stop`);
    } catch (err) {
      console.error("Recording stop failed:", err);
    }
  };

  // ── Microphone / STT ────────────────────────────────────────────────────────

  const startListening = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      audioContextRef.current = new AudioContextClass();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      const analyser = audioContextRef.current.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analyserRef.current = analyser;
      setAnalyserNode(analyser);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const updateVolume = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        const avg = dataArray.reduce((a, b) => a + b) / dataArray.length;
        setVolume(avg);
        if (avg < 5 && avg > 0 && Math.random() < 0.01) {
          showNudge("volume", "Speaking too softly — project your voice!");
        }
        animationFrameRef.current = requestAnimationFrame(updateVolume);
      };
      updateVolume();

      if (webcamEnabled) {
        await startWebcamRecording(stream);
      }

      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = true;

        recognitionRef.current.onresult = (event: any) => {
          let interimTranscript = "";
          let finalTranscript = "";
          for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) finalTranscript += event.results[i][0].transcript;
            else interimTranscript += event.results[i][0].transcript;
          }

          const fillers = ["um", "uh", "like", "you know"];
          if (fillers.some((f) => interimTranscript.toLowerCase().includes(f))) {
            showNudge("filler", "Filler word detected — try a silent pause instead.");
          }

          if (finalTranscript) handleUserTranscript(finalTranscript.trim());
        };

        recognitionRef.current.onend = () => {
          if (isListeningRef.current && recognitionRef.current) {
            try { recognitionRef.current.start(); } catch (_) {}
          }
        };

        recognitionRef.current.onerror = (event: any) => {
          if (event.error !== "no-speech") console.error("Speech recognition error:", event.error);
        };

        recognitionRef.current.start();
        isListeningRef.current = true;
        setIsListening(true);
      } else {
        alert("Your browser does not support the Web Speech API. Please use Chrome or Edge.");
      }
    } catch (err) {
      console.error("Microphone access denied", err);
      alert("Microphone access is required. Please allow it and refresh.");
    }
  };

  const stopListening = () => {
    isListeningRef.current = false;
    setIsListening(false);
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current.onend = null;
    }
    if (audioContextRef.current) audioContextRef.current.close();
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
  };

  const handleUserTranscript = async (text: string) => {
    if (!text) return;
    setMessages((prev) => [...prev, { role: "user", text }]);
    wordCountRef.current += text.split(" ").length;

    const minutes = elapsed / 60;
    if (minutes > 0.5) {
      const wpm = wordCountRef.current / minutes;
      if (wpm > 160) showNudge("pace", `Speaking too fast (${Math.round(wpm)} WPM). Slow down!`);
    }

    try {
      const { data } = await api.post(`/sessions/${sessionId}/chat`, { text });
      const aiResponse = data.reply || "I understand. Please continue.";
      setMessages((prev) => [...prev, { role: "ai", text: aiResponse }]);
      speakAI(aiResponse);
    } catch {
      const aiResponse = "Interesting point. Can you elaborate?";
      setMessages((prev) => [...prev, { role: "ai", text: aiResponse }]);
      speakAI(aiResponse);
    }
  };

  const speakAI = (text: string) => {
    if (!("speechSynthesis" in window)) return;
    const utterance = new SpeechSynthesisUtterance(text);
    if (voices.length > 0) {
      const targetVoice =
        voices.find((v) => v.name.includes("Google US English")) ||
        voices.find((v) => v.name.includes("Samantha")) ||
        voices.find((v) => v.lang === "en-US");
      if (targetVoice) utterance.voice = targetVoice;
    }
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  const startSession = () => {
    setStarted(true);
    startedAt.current = Date.now();
    timerRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    const startText = "Welcome. I'm ready to begin. Please go ahead and make your opening statement.";
    setMessages([{ role: "ai", text: startText }]);
    speakAI(startText);
    setTimeout(startListening, 3000);
  };

  const endSession = async () => {
    stopListening();
    if (timerRef.current) clearInterval(timerRef.current);
    setCompleting(true);

    if (webcamEnabled && isRecording) {
      await stopWebcamRecording();
    }

    const transcript = messages
      .map((m) => `${m.role === "user" ? "Trainee" : "AI"}: ${m.text}`)
      .join("\n");
    const duration = Math.round((Date.now() - startedAt.current) / 1000);
    const wpm = duration > 0 ? wordCountRef.current / (duration / 60) : 0;

    try {
      await sessionsApi.complete(sessionId as string, {
        transcript,
        duration_seconds: duration,
        metadata: { message_count: messages.length, pacing_wpm: Math.round(wpm) },
      });
      router.push(`/sessions/${sessionId}/feedback`);
    } catch {
      setCompleting(false);
    }
  };

  const fmt = (s: number) =>
    `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  if (!sessionData)
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "60vh" }}>
        <div className="spinner" style={{ width: 40, height: 40 }} />
      </div>
    );

  return (
    <div style={{ maxWidth: 1000, height: "calc(100vh - 80px)", display: "flex", flexDirection: "column", position: "relative" }}>
      
      {/* Live Nudge Overlay */}
      {nudge && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-50 text-xs font-medium px-3 py-1.5 rounded-full max-w-xs flex items-center gap-2 shadow-lg animate-slideDown text-white"
          style={{ background: nudge.type === "filler" ? "rgba(229,9,20,0.92)" : nudge.type === "pace" ? "rgba(245,158,11,0.92)" : "rgba(34,197,94,0.92)" }}
        >
          <span className="text-sm">
            {nudge.type === "filler" ? "🤐" : nudge.type === "pace" ? "⏱️" : "🔊"}
          </span>
          <span>{nudge.message}</span>
        </div>
      )}

      {/* Webcam preview overlay */}
      {webcamEnabled && started && (
        <div style={{
          position: "absolute", top: 16, right: 0, zIndex: 90,
          width: 180, height: 135, borderRadius: 12,
          border: isRecording ? "2px solid #E50914" : "2px solid rgba(255,255,255,0.2)",
          overflow: "hidden", background: "#000",
          boxShadow: "0 8px 20px rgba(0,0,0,0.5)",
        }}>
          <video ref={videoPreviewRef} autoPlay playsInline muted
            style={{ width: "100%", height: "100%", objectFit: "cover", transform: "scaleX(-1)" }} />
          {isRecording && (
            <div style={{
              position: "absolute", top: 8, left: 8,
              display: "flex", alignItems: "center", gap: 5,
              background: "rgba(0,0,0,0.6)", borderRadius: 20, padding: "3px 8px",
            }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#E50914", animation: "pulse 1s infinite" }} />
              <span style={{ fontSize: "0.65rem", color: "#fff", fontWeight: 700 }}>REC</span>
            </div>
          )}
        </div>
      )}

      {/* Header */}
      <div className="card flex items-center justify-between p-5 mb-5 flex-shrink-0">
        <div className="flex items-center gap-4">
          <span className="badge badge-purple flex items-center gap-2" style={{
            background: isListening ? "rgba(229,9,20,0.2)" : "",
            color: isListening ? "var(--primary)" : "",
            border: isListening ? "1px solid var(--primary)" : "",
          }}>
            {isListening ? <><div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" /> Recording</> : <><div className="w-2 h-2 rounded-full bg-red-500" /> Live Session</>}
          </span>
          <span className="text-base font-semibold">
            {sessionData?.scenario_title || "Training in Progress"}
          </span>
        </div>
        <div className="flex items-center gap-4">
          {/* Real FFT waveform */}
          <WaveformVisualizer isActive={isListening} analyserNode={analyserNode} height={48} />
          <div className={`text-2xl font-mono font-bold ${elapsed > 300 ? "text-warning" : "text-white"}`}>
            {fmt(elapsed)}
          </div>
          {started && (
            <button id="end-session-btn" onClick={endSession} className="btn btn-danger btn-sm h-9 px-4 text-sm font-medium" disabled={completing}>
              {completing ? <span className="spinner w-4 h-4" /> : <><Square size={16} /> End</>}
            </button>
          )}
        </div>
      </div>

      {/* Pre-session setup */}
      {!started ? (
        <div className="card" style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 28, padding: 48 }}>
          <div style={{ fontSize: "3rem" }}>🎙️</div>
          <h2 className="heading-md" style={{ textAlign: "center" }}>Ready for your Voice Session?</h2>
          <p style={{ color: "var(--text-secondary)", textAlign: "center", maxWidth: 480, lineHeight: 1.7 }}>
            The AI will speak to you aloud. Respond naturally using your microphone.
            SkillOS will provide live nudges for filler words, pace, and volume.
          </p>

          {/* Webcam toggle */}
          <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "16px 24px", borderRadius: 12, background: "rgba(255,255,255,0.04)", border: "1px solid var(--border)" }}>
            <span style={{ fontSize: "1.3rem" }}>🎥</span>
            <div>
              <div style={{ fontWeight: 600, fontSize: "0.92rem" }}>Enable Camera Recording</div>
              <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>Record your session for self-review (like Yoodli)</div>
            </div>
            <button
              onClick={() => setWebcamEnabled(!webcamEnabled)}
              style={{
                padding: "8px 20px", borderRadius: 20, border: "none", cursor: "pointer", fontWeight: 600, fontSize: "0.82rem",
                background: webcamEnabled ? "var(--accent)" : "rgba(255,255,255,0.1)",
                color: webcamEnabled ? "#fff" : "var(--text-secondary)",
                transition: "all 0.2s",
              }}
            >
              {webcamEnabled ? "✓ Enabled" : "Enable"}
            </button>
          </div>

          <button id="begin-session-btn" onClick={startSession} className="btn btn-primary btn-lg">
            ▶ Enable Mic & Begin
          </button>
        </div>
      ) : (
        <div className="card flex-1 flex flex-col overflow-hidden relative">
          <div className="session-chat flex-1 overflow-y-auto p-6 pb-24 flex flex-col gap-4" ref={chatRef}>
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[75%] text-sm leading-relaxed p-3 rounded-2xl ${m.role === "user" ? "bg-gradient-to-r from-red-600 to-red-800 text-white rounded-tr-none shadow-md" : "bg-white/5 border border-white/10 rounded-tl-none"}`}>
                  {m.role === "ai" && <span className="text-[10px] font-bold uppercase tracking-widest text-white/30 block mb-1">🤖 AI Persona</span>}
                  {m.text}
                </div>
              </div>
            ))}
            {isListening && (
              <div className="flex justify-end">
                <div className="max-w-[75%] text-sm leading-relaxed p-3 rounded-2xl rounded-tr-none bg-gradient-to-r from-red-600 to-red-800 text-white opacity-50 italic">Listening...</div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/50 backdrop-blur-md border-t border-white/5 flex items-center gap-3">
            <button 
              className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 transition ${isListening ? "bg-red-600 text-white" : "bg-white/10 text-white hover:bg-white/20"}`}
              onClick={isListening ? stopListening : startListening}
            >
              {isListening ? <Mic size={20} /> : <MicOff size={20} />}
            </button>
            <input className="input h-11 text-sm bg-white/5 border-white/10 rounded-lg flex-1 px-4" placeholder="Or type your response..."
              value={input} onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && input.trim()) { handleUserTranscript(input.trim()); setInput(""); } }} />
            <button id="send-message-btn" onClick={() => { if (input.trim()) { handleUserTranscript(input.trim()); setInput(""); } }}
              className="w-9 h-9 rounded-lg bg-red-600 hover:bg-red-700 flex items-center justify-center text-white transition flex-shrink-0 disabled:opacity-50" disabled={!input.trim()}>
              <Send size={16} className="-ml-0.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
