"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { sessionsApi } from "@/lib/api";
import { CATEGORY_EMOJI } from "@/lib/types";
import { FolderOpen } from "lucide-react";

const STATUS_BADGE: Record<string, string> = {
  completed: "badge-green",
  active: "badge-red animate-pulse",
  pending: "badge-gray",
};

export default function SessionsPage() {
  const [sessions, setSessions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    sessionsApi.history().then((r) => setSessions(r.data)).finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-[1000px] w-full">
      <div className="mb-8 space-y-1">
        <h1 className="text-3xl font-bold">My Sessions</h1>
        <p className="text-sm font-normal text-white/50 leading-relaxed">Your complete training history with AI feedback.</p>
      </div>

      {loading ? (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {[...Array(4)].map((_, i) => (
            <div key={i} className="skeleton" style={{ height: 72, borderRadius: "var(--radius)" }} />
          ))}
        </div>
      ) : sessions.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center">
            <FolderOpen size={24} className="text-white/20" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-semibold">No Sessions Yet</h3>
            <p className="text-sm text-white/40 max-w-sm">Complete your first scenario to see your training history here.</p>
          </div>
          <Link href="/scenarios" className="btn btn-primary h-9 px-4 text-sm font-medium">Browse Scenarios</Link>
        </div>
      ) : (
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Scenario</th>
                <th>Status</th>
                <th>Date</th>
                <th>Duration</th>
                <th>Score</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {sessions.map((s) => {
                const score = s.overall_score;
                const scoreColor = score >= 70 ? "var(--success)" : score >= 50 ? "var(--warning)" : "var(--danger)";
                return (
                  <tr key={s.id}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{CATEGORY_EMOJI[s.category] || "🎯"}</span>
                        <div>
                          <div className="text-sm font-semibold">{s.scenario_title || "Training Session"}</div>
                          <div className="text-xs font-normal text-white/50 capitalize">{s.category || "general"}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`badge ${STATUS_BADGE[s.status] || "badge-gray"}`}>
                        {s.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm font-normal text-white/70">
                      {s.completed_at
                        ? new Date(s.completed_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
                        : new Date(s.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                    </td>
                    <td className="px-4 py-3 text-sm font-normal text-white/70">
                      {s.duration_seconds ? `${Math.round(s.duration_seconds / 60)}m ${s.duration_seconds % 60}s` : "—"}
                    </td>
                    <td className="px-4 py-3">
                      {score != null ? (
                        <span className="text-base font-bold" style={{ color: scoreColor }}>
                          {Math.round(score)}
                          <span className="text-[10px] text-white/50 font-medium ml-0.5">/100</span>
                        </span>
                      ) : (
                        <span className="text-sm font-normal text-white/30">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div style={{ display: "flex", gap: 8 }}>
                        {s.status === "completed" && (
                          <Link href={`/sessions/${s.id}/feedback`} className="btn btn-secondary btn-sm">
                            Feedback
                          </Link>
                        )}
                        {s.status === "active" && (
                          <Link href={`/sessions/${s.id}`} className="btn btn-primary btn-sm">
                            Resume →
                          </Link>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
