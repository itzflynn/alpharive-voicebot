"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { scenariosApi } from "@/lib/api";
import type { Scenario } from "@/lib/types";
import { CATEGORY_EMOJI, DIFFICULTY_COLOR } from "@/lib/types";
import { Search, Clock, Play } from "lucide-react";

const CATS = ["all", "sales", "customer_service", "leadership", "interviews", "negotiation"];

export default function ScenariosPage() {
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [cat, setCat] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    scenariosApi.list(cat !== "all" ? { category: cat } : {})
      .then((r) => setScenarios(r.data))
      .finally(() => setLoading(false));
  }, [cat]);

  return (
    <div className="max-w-[1300px] w-full">
      <div className="mb-8 space-y-1">
        <h1 className="text-3xl font-bold">Training Scenarios</h1>
        <p className="text-sm font-normal text-white/50 leading-relaxed">Choose a scenario and start practicing. AI feedback is generated instantly on completion.</p>
      </div>

      {/* Category filter */}
      <div className="flex flex-wrap gap-2 mb-8">
        {CATS.map((c) => (
          <button key={c} onClick={() => setCat(c)}
            className={`btn btn-sm ${cat === c ? "btn-primary" : "btn-secondary"}`}
            style={{ textTransform: "capitalize" }}>
            {c === "all" ? "All Categories" : `${CATEGORY_EMOJI[c] || ""} ${c.replace("_", " ")}`}
          </button>
        ))}
      </div>

      {/* Scenarios grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array(6).fill(0).map((_, i) => (
            <div key={i} className="card p-5 h-60">
              <div className="skeleton h-[120px] mb-4" />
              <div className="skeleton h-5 mb-2 w-[70%]" />
              <div className="skeleton h-3.5 w-[90%]" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {scenarios.map((s) => (
            <Link href={`/scenarios/${s.id}`} key={s.id}>
              <div className="card scenario-card overflow-hidden">
                <div className="h-40 w-full bg-white/5 relative flex items-center justify-center">
                  <span className="text-5xl">{CATEGORY_EMOJI[s.category] || "🎭"}</span>
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <span className={`badge ${DIFFICULTY_COLOR[s.difficulty] || "badge-purple"}`}>{s.difficulty}</span>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">{s.category.replace("_", " ")}</span>
                  </div>
                  <h3 className="text-base font-semibold mb-2">{s.title}</h3>
                  <p className="text-sm font-normal text-white/50 leading-relaxed mb-4">
                    {s.description?.slice(0, 90)}...
                  </p>
                  <div className="flex items-center gap-4 text-xs font-medium text-white/40">
                    <span className="flex items-center gap-1"><Clock size={12} /> {s.duration_minutes} min</span>
                    <span className="flex items-center gap-1"><Play size={12} /> {s.play_count} sessions</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}

      {!loading && scenarios.length === 0 && (
        <div className="flex flex-col items-center justify-center py-24 text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center">
            <Search size={24} className="text-white/20" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-semibold">No Scenarios Found</h3>
            <p className="text-sm text-white/40 max-w-sm">There are no scenarios matching the selected category.</p>
          </div>
          <button onClick={() => setCat("all")} className="btn btn-primary btn-sm">Clear Filter</button>
        </div>
      )}
    </div>
  );
}
