"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { customScenariosApi } from "@/lib/api";

const SKILLS = ["confidence", "clarity", "tone", "persuasion", "filler_control"];
const DIFFICULTIES = ["beginner", "intermediate", "advanced"];

export default function CreateScenarioPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    title: "",
    description: "",
    persona_name: "",
    persona_role: "",
    personality_prompt: "",
    difficulty: "intermediate",
    duration_minutes: 10,
    skills_targeted: ["confidence", "clarity"] as string[],
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const update = (field: string, value: any) => setForm((prev) => ({ ...prev, [field]: value }));

  const toggleSkill = (skill: string) => {
    setForm((prev) => ({
      ...prev,
      skills_targeted: prev.skills_targeted.includes(skill)
        ? prev.skills_targeted.filter((s) => s !== skill)
        : [...prev.skills_targeted, skill],
    }));
  };

  const handleSubmit = async () => {
    if (!form.title || !form.persona_name || !form.persona_role || !form.personality_prompt) {
      setError("Please fill in all required fields.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      const { data } = await customScenariosApi.create(form);
      router.push(`/scenarios/${data.id}`);
    } catch (e: any) {
      setError(e?.response?.data?.detail || "Failed to create scenario. Please try again.");
      setSaving(false);
    }
  };

  const previewIntro = form.persona_name && form.persona_role && form.personality_prompt
    ? `Hi, I'm ${form.persona_name}, ${form.persona_role}. ${form.personality_prompt.split(".")[0]}.`
    : null;

  return (
    <div className="max-w-[860px] w-full">
      <div className="mb-8 space-y-1">
        <h1 className="text-3xl font-bold">Create Custom Scenario</h1>
        <p className="text-sm font-normal text-white/50 leading-relaxed">
          Design your own AI training scenario with a custom persona. Your AI coach will roleplay exactly as you define.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[1fr_340px] gap-6">
        {/* Form */}
        <div className="flex flex-col gap-6">

          {/* Title */}
          <div className="card p-6">
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">
              Scenario Title *
            </label>
            <input className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg placeholder:text-white/30 focus:border-red-600 focus:ring-1 focus:ring-red-600 mb-5" placeholder="e.g., Investor Pitch: Series A Meeting"
              value={form.title} onChange={(e) => update("title", e.target.value)} />
            
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">
              Description
            </label>
            <input className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg placeholder:text-white/30 focus:border-red-600 focus:ring-1 focus:ring-red-600" placeholder="Brief summary of what this scenario trains"
              value={form.description} onChange={(e) => update("description", e.target.value)} />
          </div>

          {/* Persona */}
          <div className="card p-6">
            <h3 className="text-base font-semibold mb-4">🎭 AI Persona</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Name *</label>
                <input className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg placeholder:text-white/30 focus:border-red-600 focus:ring-1 focus:ring-red-600" placeholder="e.g., Alex"
                  value={form.persona_name} onChange={(e) => update("persona_name", e.target.value)} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Role / Title *</label>
                <input className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg placeholder:text-white/30 focus:border-red-600 focus:ring-1 focus:ring-red-600" placeholder="e.g., Series A VC Partner"
                  value={form.persona_role} onChange={(e) => update("persona_role", e.target.value)} />
              </div>
            </div>
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Personality & Behavior * <span className="opacity-60 lowercase normal-case tracking-normal font-normal">(this becomes the AI's system prompt)</span></label>
            <textarea className="input w-full p-4 text-sm bg-white/5 border border-white/10 rounded-lg placeholder:text-white/30 focus:border-red-600 focus:ring-1 focus:ring-red-600 resize-y" rows={5}
              placeholder="Describe how this persona should behave. E.g., 'You are a skeptical but fair VC. Ask hard questions about TAM, unit economics, and competition. Only invest if the founder demonstrates deep market knowledge and clarity of vision.'"
              value={form.personality_prompt}
              onChange={(e) => update("personality_prompt", e.target.value)} />
          </div>

          {/* Settings */}
          <div className="card p-6">
            <h3 className="text-base font-semibold mb-4">⚙️ Session Settings</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
              <div>
                <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Difficulty</label>
                <select className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg focus:border-red-600 focus:ring-1 focus:ring-red-600 cursor-pointer" value={form.difficulty} onChange={(e) => update("difficulty", e.target.value)}>
                  {DIFFICULTIES.map((d) => <option key={d} value={d} className="bg-black/90">{d.charAt(0).toUpperCase() + d.slice(1)}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Duration (minutes)</label>
                <input className="input w-full h-11 px-4 text-sm bg-white/5 border border-white/10 rounded-lg focus:border-red-600 focus:ring-1 focus:ring-red-600" type="number" min={3} max={30} value={form.duration_minutes}
                  onChange={(e) => update("duration_minutes", parseInt(e.target.value) || 10)} />
              </div>
            </div>
            <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-3">Skills this scenario develops</label>
            <div className="flex flex-wrap gap-2">
              {SKILLS.map((skill) => {
                const active = form.skills_targeted.includes(skill);
                return (
                  <button key={skill} onClick={() => toggleSkill(skill)}
                    className={`text-[11px] font-semibold px-3 py-1.5 rounded-full border transition-colors ${active ? "border-red-600 bg-red-600/10 text-red-500" : "border-white/10 bg-transparent text-white/50 hover:bg-white/5"}`}>
                    {skill.replace("_", " ")}
                  </button>
                );
              })}
            </div>
          </div>

          {error && <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">{error}</div>}

          <button onClick={handleSubmit} disabled={saving} className="btn btn-primary h-11 px-6 text-base font-semibold w-full mt-2">
            {saving ? <><span className="spinner w-5 h-5 border-t-white" /> Saving...</> : "Save Scenario & Start Training →"}
          </button>
        </div>

        {/* Live Preview */}
        <div>
          <div className="card p-6 sticky top-5">
            <h3 className="text-base font-semibold mb-1">Live Preview</h3>
            <p className="text-xs font-normal text-white/50 mb-5">How your AI persona will open the session:</p>

            <div className="flex gap-3 items-start">
              <div className="w-10 h-10 rounded-full bg-red-600 flex items-center justify-center text-lg flex-shrink-0 shadow-lg border border-red-500/20">
                🤖
              </div>
              <div className="bg-white/5 border border-white/10 rounded-2xl rounded-tl-none p-4 flex-1">
                {previewIntro ? (
                  <p className="text-sm leading-relaxed text-white/70">{previewIntro}</p>
                ) : (
                  <p className="text-xs text-white/40 italic">
                    Fill in the persona details to see a preview...
                  </p>
                )}
              </div>
            </div>

            <div className="mt-6 p-4 bg-white/5 rounded-xl border border-white/5">
              <div className="text-[10px] font-bold text-white/40 uppercase tracking-wider mb-2">Session Details</div>
              <div className="flex flex-col gap-1.5 text-xs text-white/60">
                <div className="flex items-center gap-2"><span className="text-white/40 w-4">📌</span> {form.title || "Untitled Scenario"}</div>
                <div className="flex items-center gap-2"><span className="text-white/40 w-4">⏱</span> {form.duration_minutes} minutes</div>
                <div className="flex items-center gap-2"><span className="text-white/40 w-4">🎯</span> <span className="capitalize">{form.difficulty}</span></div>
                <div className="flex items-center gap-2"><span className="text-white/40 w-4">📚</span> <span className="capitalize">{form.skills_targeted.join(", ").replace(/_/g, " ") || "No skills selected"}</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
