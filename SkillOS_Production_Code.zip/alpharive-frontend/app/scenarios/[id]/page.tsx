"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { scenariosApi, sessionsApi } from "@/lib/api";
import type { Scenario } from "@/lib/types";
import { CATEGORY_EMOJI, DIFFICULTY_COLOR } from "@/lib/types";
import { ArrowLeft, Clock, Play } from "lucide-react";

export default function ScenarioDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    scenariosApi.get(id).then((r) => setScenario(r.data));
  }, [id]);

  const startSession = async () => {
    if (!scenario) return;
    setLoading(true);
    try {
      const { data } = await sessionsApi.start(scenario.id);
      router.push(`/sessions/${data.session_id}`);
    } catch { setLoading(false); }
  };

  if (!scenario) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "60vh" }}>
      <div className="spinner" style={{ width: 40, height: 40 }} />
    </div>
  );

  return (
    <div className="max-w-[800px] w-full">
      <button onClick={() => router.back()} className="btn btn-ghost h-7 px-3 text-xs font-medium mb-6">
        <ArrowLeft size={14} className="mr-1" /> Back
      </button>

      <div className="card p-6 md:p-8 mb-6">
        {/* Scenario detail hero */}
        <div className="h-64 w-full object-cover bg-white/5 relative flex items-center justify-center mb-6 rounded-xl overflow-hidden border border-white/10">
          <span className="text-[5rem]">{CATEGORY_EMOJI[scenario.category] || "🎭"}</span>
        </div>

        <div className="flex flex-wrap gap-3 mb-5">
          <span className={`badge ${DIFFICULTY_COLOR[scenario.difficulty]}`}>{scenario.difficulty}</span>
          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">{scenario.category.replace("_", " ")}</span>
          <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1"><Clock size={12} /> {scenario.duration_minutes} min</span>
        </div>

        <h1 className="text-3xl font-bold mb-4">{scenario.title}</h1>
        <p className="text-sm font-normal leading-relaxed text-white/70 mb-6">{scenario.description}</p>

        <div className="flex flex-wrap gap-2 mb-8">
          {scenario.skills_targeted.map((skill) => (
            <span key={skill} className="badge badge-purple" style={{ textTransform: "capitalize" }}>{skill.replace("_", " ")}</span>
          ))}
        </div>

        <div className="card p-6 mb-8" style={{ background: "var(--gradient-subtle)", borderColor: "rgba(124,58,237,0.2)" }}>
          <h3 className="text-base font-semibold mb-3">📋 Scenario Briefing</h3>
          <p className="text-sm leading-loose text-white/70">{scenario.briefing}</p>
        </div>

        <div className="card p-6 mb-8" style={{ background: "rgba(6,182,212,0.06)", borderColor: "rgba(6,182,212,0.2)" }}>
          <h3 className="text-sm font-semibold text-cyan-400 mb-3">🎯 You will be evaluated on:</h3>
          <div className="flex flex-wrap gap-2">
            {["Confidence", "Clarity", "Tone", "Persuasion", "Filler Control"].map((d) => (
              <span key={d} className="badge badge-cyan">{d}</span>
            ))}
          </div>
        </div>

        <button id={`start-session-${scenario.id}`} onClick={startSession} className="btn btn-primary h-11 px-6 text-base font-semibold w-full" disabled={loading}>
          {loading ? <><span className="spinner w-5 h-5 border-t-white" /> Starting...</> : <><Play size={18} /> Start Training Session</>}
        </button>
      </div>
    </div>
  );
}
