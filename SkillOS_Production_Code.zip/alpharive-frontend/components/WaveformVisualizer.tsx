"use client";
import { useEffect, useRef } from "react";

interface WaveformVisualizerProps {
  isActive: boolean;
  analyserNode: AnalyserNode | null;
  barCount?: number;
  height?: number;
  color?: string;
}

export default function WaveformVisualizer({
  isActive,
  analyserNode,
  barCount = 48,
  height = 48,
  color = "#E50914",
}: WaveformVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);
  const idlePhaseRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    const barW = Math.floor(W / barCount) - 1;

    const draw = () => {
      ctx.clearRect(0, 0, W, H);

      if (analyserNode && isActive) {
        // ── Real FFT data ──────────────────────────────────────────────────
        const dataArray = new Uint8Array(analyserNode.frequencyBinCount);
        analyserNode.getByteFrequencyData(dataArray);

        // We sample only the lower portion of the spectrum (voice range)
        const usableBins = Math.floor(dataArray.length * 0.5);
        const step = Math.floor(usableBins / barCount);

        for (let i = 0; i < barCount; i++) {
          // Average a few bins for smoother look
          let sum = 0;
          for (let j = 0; j < step; j++) {
            sum += dataArray[i * step + j] || 0;
          }
          const avg = sum / step;
          const barHeight = Math.max(3, (avg / 255) * H);

          const x = i * (barW + 1);
          const y = H - barHeight;

          // Gradient from accent to slightly lighter
          const gradient = ctx.createLinearGradient(x, y, x, H);
          gradient.addColorStop(0, color);
          gradient.addColorStop(1, `${color}55`);

          ctx.fillStyle = gradient;
          ctx.beginPath();
          ctx.roundRect(x, y, barW, barHeight, 2);
          ctx.fill();
        }
      } else {
        // ── Idle animation — gentle sine wave ──────────────────────────────
        idlePhaseRef.current += 0.06;
        for (let i = 0; i < barCount; i++) {
          const t = idlePhaseRef.current + i * 0.4;
          const idleH = Math.max(3, (Math.sin(t) * 0.5 + 0.5) * H * 0.18 + 3);
          const x = i * (barW + 1);
          const y = H - idleH;

          ctx.fillStyle = isActive ? `${color}40` : "rgba(255,255,255,0.12)";
          ctx.beginPath();
          ctx.roundRect(x, y, barW, idleH, 2);
          ctx.fill();
        }
      }

      animFrameRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [isActive, analyserNode, barCount, height, color]);

  return (
    <canvas
      ref={canvasRef}
      width={barCount * (Math.floor(320 / barCount))}
      height={height}
      style={{
        display: "block",
        borderRadius: 8,
        background: "transparent",
      }}
    />
  );
}
