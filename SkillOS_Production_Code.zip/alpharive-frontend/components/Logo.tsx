import React from "react";

export default function Logo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2L2 7.5V16.5L12 22L22 16.5V7.5L12 2Z" stroke="#E50914" strokeWidth="2" strokeLinejoin="round"/>
        <path d="M9 10C9 8.5 10 7.5 11 7.5C12 7.5 12.5 8 12.5 8C12.5 8 13 7.5 14 7.5C15 7.5 16 8.5 16 10C16 11 15.5 11.5 15.5 11.5C16 12 16 13 15 14C14.5 14.5 13.5 15 12.5 15C12.5 15 12 16 12 16C12 16 11.5 15 11.5 15C10.5 15 9.5 14.5 9 14C8 13 8 12 8.5 11.5C8.5 11.5 8 11 9 10Z" stroke="#E50914" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 8V16" stroke="#E50914" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
      <span style={{ fontSize: "1.4rem", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}>
        SkillOS
      </span>
    </div>
  );
}
