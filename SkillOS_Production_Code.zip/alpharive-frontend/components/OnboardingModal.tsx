"use client";
import { useEffect, useRef, useState } from "react";
import { authApi, scenariosApi, sessionsApi } from "@/lib/api";
import { useRouter } from "next/navigation";

const GOALS = [
  { id: "sales", icon: "💼", label: "Sales", desc: "Cold calls, pitches, objection handling" },
  { id: "leadership", icon: "🏆", label: "Leadership", desc: "Feedback, board presentations, 1-on-1s" },
  { id: "interviews", icon: "🎯", label: "Job Interviews", desc: "Behavioral, technical, salary negotiation" },
  { id: "customer_service", icon: "🎧", label: "Customer Success", desc: "De-escalation, retention, support" },
  { id: "negotiation", icon: "🤝", label: "Negotiation", desc: "Pricing, vendor deals, competing offers" },
];

interface OnboardingModalProps {
  onComplete: () => void;
}

export default function OnboardingModal({ onComplete }: OnboardingModalProps) {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  const [micConfirmed, setMicConfirmed] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);
  const [recommendedScenario, setRecommendedScenario] = useState<any>(null);
  const [starting, setStarting] = useState(false);

  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number>(0);
  const streamRef = useRef<MediaStream | null>(null);

  // Start mic test when reaching step 3
  useEffect(() => {
    if (step === 3) startMicTest();
    return () => stopMicTest();
  }, [step]);

  // Load recommended scenario on step 4
  useEffect(() => {
    if (step === 4 && selectedGoal) {
      scenariosApi.list({ category: selectedGoal, difficulty: "beginner" }).then((r) => {
        const scenarios = r.data as any[];
        if (scenarios.length > 0) setRecommendedScenario(scenarios[0]);
        else {
          // fallback: any beginner scenario
          scenariosApi.list({ difficulty: "beginner" }).then((r2) => {
            const all = r2.data as any[];
            if (all.length > 0) setRecommendedScenario(all[0]);
          });
        }
      });
    }
  }, [step, selectedGoal]);

  const startMicTest = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      audioContextRef.current = new AudioContext();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      const analyser = audioContextRef.current.createAnalyser();
      analyser.fftSize = 128;
      source.connect(analyser);
      analyserRef.current = analyser;

      const data = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        analyser.getByteFrequencyData(data);
        const avg = data.reduce((a, b) => a + b, 0) / data.length;
        setAudioLevel(avg);
        if (avg > 8) setMicConfirmed(true);
        animFrameRef.current = requestAnimationFrame(tick);
      };
      tick();
    } catch {
      setMicConfirmed(false);
    }
  };

  const stopMicTest = () => {
    cancelAnimationFrame(animFrameRef.current);
    if (audioContextRef.current) audioContextRef.current.close();
    if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
  };

  const handleGoalSelect = async () => {
    if (!selectedGoal) return;
    await authApi.updateMe({ primary_goal: selectedGoal });
    setStep(3);
  };

  const handleComplete = async () => {
    if (!recommendedScenario) return;
    setStarting(true);
    stopMicTest();
    await authApi.updateMe({ onboarding_completed: true });
    const { data } = await sessionsApi.start(recommendedScenario.id);
    router.push(`/sessions/${data.session_id}`);
    onComplete();
  };

  const progress = (step / 4) * 100;

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 9999,
      background: "rgba(0,0,0,0.85)", backdropFilter: "blur(12px)",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: 24,
    }}>
      <div style={{
        background: "var(--bg-card)", border: "1px solid var(--border)",
        borderRadius: 24, width: "100%", maxWidth: 560,
        padding: "40px 48px", position: "relative",
        boxShadow: "0 40px 80px rgba(0,0,0,0.6)",
      }}>
        {/* Progress bar */}
        <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, borderRadius: "24px 24px 0 0", background: "rgba(255,255,255,0.06)" }}>
          <div style={{ height: "100%", width: `${progress}%`, background: "var(--accent)", borderRadius: 24, transition: "width 0.4s ease" }} />
        </div>

        <div style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginBottom: 28, marginTop: 8 }}>
          Step {step} of 4
        </div>

        {/* Step 1: Welcome */}
        {step === 1 && (
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: "3.5rem", marginBottom: 20 }}>🎙️</div>
            <h2 className="heading-md" style={{ marginBottom: 12 }}>Welcome to SkillOS</h2>
            <p style={{ color: "var(--text-secondary)", lineHeight: 1.8, marginBottom: 36 }}>
              Let's set up your training profile in 4 quick steps. You'll be practicing with an AI coach in under 2 minutes.
            </p>
            <button onClick={() => setStep(2)} className="btn btn-primary btn-lg w-full">
              Let's Get Started →
            </button>
          </div>
        )}

        {/* Step 2: Goal selection */}
        {step === 2 && (
          <div>
            <h2 className="heading-md" style={{ marginBottom: 8 }}>What's your primary goal?</h2>
            <p style={{ color: "var(--text-secondary)", marginBottom: 24, fontSize: "0.9rem" }}>We'll personalize your first session based on this.</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 28 }}>
              {GOALS.map((g) => (
                <button key={g.id} onClick={() => setSelectedGoal(g.id)}
                  style={{
                    display: "flex", alignItems: "center", gap: 16, padding: "14px 18px",
                    borderRadius: 12, border: `1px solid ${selectedGoal === g.id ? "var(--accent)" : "var(--border)"}`,
                    background: selectedGoal === g.id ? "rgba(229,9,20,0.1)" : "rgba(255,255,255,0.02)",
                    cursor: "pointer", textAlign: "left", transition: "all 0.2s",
                  }}>
                  <span style={{ fontSize: "1.5rem", flexShrink: 0 }}>{g.icon}</span>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: "0.9rem" }}>{g.label}</div>
                    <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>{g.desc}</div>
                  </div>
                  {selectedGoal === g.id && <span style={{ marginLeft: "auto", color: "var(--accent)", fontWeight: 700 }}>✓</span>}
                </button>
              ))}
            </div>
            <button onClick={handleGoalSelect} disabled={!selectedGoal} className="btn btn-primary w-full">
              Continue →
            </button>
          </div>
        )}

        {/* Step 3: Mic test */}
        {step === 3 && (
          <div style={{ textAlign: "center" }}>
            <h2 className="heading-md" style={{ marginBottom: 8 }}>Microphone Check</h2>
            <p style={{ color: "var(--text-secondary)", marginBottom: 32, fontSize: "0.9rem" }}>
              Say something to confirm your mic is working.
            </p>

            {/* Audio level meter */}
            <div style={{ display: "flex", gap: 4, alignItems: "flex-end", justifyContent: "center", height: 64, marginBottom: 28 }}>
              {Array.from({ length: 24 }).map((_, i) => {
                const threshold = (i / 24) * 80;
                const active = audioLevel > threshold;
                return (
                  <div key={i} style={{
                    width: 8, borderRadius: 4, transition: "height 0.08s, background 0.08s",
                    height: active ? `${Math.min(100, ((audioLevel - threshold) / 80) * 100 + 20)}%` : "15%",
                    background: active ? (i < 16 ? "var(--accent)" : "#f59e0b") : "rgba(255,255,255,0.1)",
                  }} />
                );
              })}
            </div>

            {micConfirmed ? (
              <div style={{ display: "flex", alignItems: "center", gap: 8, justifyContent: "center", color: "var(--success)", fontWeight: 600, marginBottom: 28 }}>
                <span style={{ fontSize: "1.3rem" }}>✓</span> Mic detected — you're all set!
              </div>
            ) : (
              <p style={{ color: "var(--text-muted)", fontSize: "0.85rem", marginBottom: 28 }}>Speak now to test your microphone...</p>
            )}

            <button onClick={() => { stopMicTest(); setStep(4); }} disabled={!micConfirmed}
              className="btn btn-primary w-full" style={{ opacity: micConfirmed ? 1 : 0.5 }}>
              Continue →
            </button>
            <button onClick={() => { stopMicTest(); setStep(4); }}
              style={{ background: "none", border: "none", color: "var(--text-muted)", cursor: "pointer", marginTop: 12, fontSize: "0.82rem" }}>
              Skip mic test
            </button>
          </div>
        )}

        {/* Step 4: First scenario */}
        {step === 4 && (
          <div style={{ textAlign: "center" }}>
            <h2 className="heading-md" style={{ marginBottom: 8 }}>Your First Session</h2>
            <p style={{ color: "var(--text-secondary)", marginBottom: 28, fontSize: "0.9rem" }}>
              We've picked the perfect first scenario for you.
            </p>
            {recommendedScenario ? (
              <div className="card" style={{ padding: "24px", marginBottom: 28, textAlign: "left" }}>
                <div style={{ display: "flex", gap: 16, alignItems: "flex-start" }}>
                  <div style={{ fontSize: "2.5rem", flexShrink: 0 }}>🎭</div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: "1rem", marginBottom: 6 }}>{recommendedScenario.title}</div>
                    <div style={{ fontSize: "0.82rem", color: "var(--text-secondary)", lineHeight: 1.6, marginBottom: 10 }}>{recommendedScenario.description}</div>
                    <div style={{ display: "flex", gap: 8 }}>
                      <span className="badge badge-green">Beginner</span>
                      <span className="badge badge-gray">{recommendedScenario.duration_minutes} min</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div style={{ height: 120, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <div className="spinner" style={{ width: 32, height: 32 }} />
              </div>
            )}
            <button onClick={handleComplete} disabled={!recommendedScenario || starting}
              className="btn btn-primary btn-lg w-full">
              {starting ? <span className="spinner" style={{ width: 20, height: 20 }} /> : "Start My First Session →"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
