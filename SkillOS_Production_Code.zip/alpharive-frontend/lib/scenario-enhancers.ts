import { Scenario } from "./types";

export interface EnhancedScenario extends Scenario {
  outcomeTitle: string;
  thumbnailUrl: string;
  successRate: string;
  popularity: string;
  aiFeedbackType: string;
  moodColor: string;
  aiPersonality: string;
}

export function enhanceScenario(s: Scenario): EnhancedScenario {
  // Title map to "Outcome Driven" Netflix-style titles
  const titleMap: Record<string, string> = {
    "Cold Call: Skeptical Gatekeeper": "Break Through a Gatekeeper in 60 Seconds",
    "Demo Closing: The Price Objection": "Close the Deal Despite Price Objections",
    "Angry Customer: Billing Dispute": "De-escalate an Angry Client Before Churn",
    "Escalation Management: Product Failure": "Save a VIP Account from Churning",
    "Difficult Feedback: Underperforming Team Member": "Turn Around an Underperformer",
    "Executive Presentation: Board Strategy Update": "Win Board Approval for a Pivot",
    "Behavioral Interview: Tell Me About a Time": "Nail the Toughest Interview Question",
    "Technical Interview: System Design": "Ace the System Design Deep-Dive",
    "Salary Negotiation: Competing Offer": "Negotiate a 20% Higher Salary"
  };

  let cleanTitle = s.title;
  // Try to match ignoring trailing ellipses or whitespace
  for (const [key, value] of Object.entries(titleMap)) {
    if (s.title.includes(key) || key.includes(s.title.replace("...", ""))) {
      cleanTitle = value;
      break;
    }
  }

  // Real photographic contextual scene thumbnails from Unsplash
  const thumbMap: Record<string, string> = {
    "sales": "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=600&h=400&fit=crop",
    "customer_service": "https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=600&h=400&fit=crop",
    "leadership": "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=600&h=400&fit=crop",
    "interviews": "https://images.unsplash.com/photo-1573497620053-ea5300f94f21?w=600&h=400&fit=crop",
    "negotiation": "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&h=400&fit=crop",
  };
  const thumbnailUrl = thumbMap[s.category] || "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&h=400&fit=crop";

  // Generate deterministic mock data based on ID
  const charCode = s.id ? s.id.charCodeAt(0) + s.id.charCodeAt(s.id.length - 1) : 100;
  const successRate = 60 + (charCode % 35); // 60% - 95%
  const popCount = 1000 + (charCode * 42); // 1k+ range
  const popularity = `${(popCount / 1000).toFixed(1)}k attempts`;
  const aiFeedbackType = "Voice + Behavioral Analysis";

  // Mood color and personality
  const moodMap: Record<string, { color: string, personality: string }> = {
    "sales": { color: "rgba(16, 185, 129, 0.4)", personality: "Skeptical" }, // Emerald
    "customer_service": { color: "rgba(239, 68, 68, 0.4)", personality: "Aggressive" }, // Red
    "leadership": { color: "rgba(139, 92, 246, 0.4)", personality: "Defensive" }, // Purple
    "interviews": { color: "rgba(59, 130, 246, 0.4)", personality: "Analytical" }, // Blue
    "negotiation": { color: "rgba(245, 158, 11, 0.4)", personality: "Assertive" } // Amber
  };
  
  const moodColor = moodMap[s.category]?.color || "rgba(255,255,255,0.2)";
  const aiPersonality = moodMap[s.category]?.personality || "Neutral";

  return {
    ...s,
    outcomeTitle: cleanTitle,
    thumbnailUrl,
    successRate: `${successRate}%`,
    popularity,
    aiFeedbackType,
    moodColor,
    aiPersonality
  };
}
