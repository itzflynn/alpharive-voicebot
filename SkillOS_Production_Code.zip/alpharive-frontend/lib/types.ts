export interface User {
  id: string;
  email: string;
  full_name: string;
  role: string;
  org_id: string;
  avatar_url?: string;
  onboarding_completed?: boolean;
  primary_goal?: string;
}

export interface Scenario {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  skills_targeted: string[];
  duration_minutes: number;
  briefing: string;
  thumbnail_url?: string;
  is_published: boolean;
  play_count: number;
  is_custom?: boolean;
  persona_name?: string;
  persona_role?: string;
  created_at: string;
}

export interface Session {
  id: string;
  scenario_id: string;
  status: string;
  started_at?: string;
  completed_at?: string;
  duration_seconds?: number;
  recording_url?: string;
  share_token?: string;
  created_at: string;
}

export interface VocabularyAnalysis {
  power_words_used: string[];
  power_word_count: number;
  weak_words_used: string[];
  weak_word_count: number;
  vocabulary_diversity: number;
  avg_sentence_length: number;
  question_ratio: number;
  vocabulary_score: number;
}

export interface Feedback {
  id: string;
  session_id: string;
  overall_score: number;
  confidence_score: number;
  clarity_score: number;
  tone_score: number;
  persuasion_score: number;
  filler_control_score: number;
  filler_word_count: number;
  filler_words: string[];
  strengths: string[];
  improvements: string[];
  detailed_feedback: string;
  improvement_plan: { this_week: string; this_month: string; long_term: string };
  next_recommended_scenario: string;
  pacing_wpm?: number;
  rephrasing_suggestions?: { original: string; improved: string }[];
  vocabulary_analysis?: VocabularyAnalysis;
  eye_contact_score?: number;
  smile_score?: number;
  pronunciation_score?: number;
  pronunciation_feedback?: string;
  generated_at: string;
}

export interface AnalyticsSummary {
  sessions_completed: number;
  average_score: number;
  best_score: number;
  streak_days: number;
  longest_streak: number;
}

export const CATEGORY_EMOJI: Record<string, string> = {
  sales: "💼",
  customer_service: "🎧",
  leadership: "🏆",
  interviews: "🎯",
  negotiation: "🤝",
  custom: "✏️",
};

export const DIFFICULTY_COLOR: Record<string, string> = {
  beginner: "badge-green",
  intermediate: "badge-yellow",
  advanced: "badge-red",
};
