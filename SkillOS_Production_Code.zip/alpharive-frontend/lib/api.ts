import axios from "axios";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export const api = axios.create({ baseURL: API_URL });

api.interceptors.request.use((config) => {
  if (typeof window !== "undefined") {
    const token = localStorage.getItem("access_token");
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (r) => r,
  async (err) => {
    if (err.response?.status === 401 && typeof window !== "undefined") {
      const refresh = localStorage.getItem("refresh_token");
      if (refresh) {
        try {
          const { data } = await axios.post(`${API_URL}/auth/refresh`, { refresh_token: refresh });
          localStorage.setItem("access_token", data.access_token);
          localStorage.setItem("refresh_token", data.refresh_token);
          err.config.headers.Authorization = `Bearer ${data.access_token}`;
          return api(err.config);
        } catch {
          localStorage.clear();
          window.location.href = "/login";
        }
      }
    }
    return Promise.reject(err);
  }
);

// ── Auth ────────────────────────────────────────────────────────────────────
export const authApi = {
  register: (body: { email: string; password: string; first_name: string; last_name: string }) =>
    api.post("/auth/register", body),
  login: (body: { email: string; password: string }) => api.post("/auth/login", body),
  me: () => api.get("/auth/me"),
  updateMe: (body: { onboarding_completed?: boolean; primary_goal?: string; full_name?: string }) =>
    api.patch("/auth/me", body),
};

// ── Scenarios ───────────────────────────────────────────────────────────────
export const scenariosApi = {
  list: (params?: { category?: string; difficulty?: string }) => api.get("/scenarios", { params }),
  get: (id: string) => api.get(`/scenarios/${id}`),
  categories: () => api.get("/scenarios/categories"),
};

// ── Custom Scenarios ─────────────────────────────────────────────────────────
export const customScenariosApi = {
  create: (body: {
    title: string; description: string; persona_name: string; persona_role: string;
    personality_prompt: string; difficulty: string; skills_targeted: string[]; duration_minutes: number;
  }) => api.post("/scenarios/custom", body),
  mine: () => api.get("/scenarios/custom/mine"),
  delete: (id: string) => api.delete(`/scenarios/custom/${id}`),
};

// ── Sessions ────────────────────────────────────────────────────────────────
export const sessionsApi = {
  start: (scenario_id: string) => api.post("/sessions/start", { scenario_id }),
  complete: (session_id: string, body: { transcript: string; duration_seconds: number; metadata?: object }) =>
    api.post(`/sessions/${session_id}/complete`, body),
  history: () => api.get("/sessions/history"),
  get: (id: string) => api.get(`/sessions/${id}`),
  feedback: (session_id: string) => api.get(`/sessions/${session_id}/feedback`),
  share: (session_id: string) => api.post(`/sessions/${session_id}/share`),
};

// ── Analytics ───────────────────────────────────────────────────────────────
export const analyticsApi = {
  summary: () => api.get("/analytics/summary"),
  skills: () => api.get("/analytics/skills"),
  skillHistory: (skill: string) => api.get(`/analytics/skill-history?skill=${skill}`),
  recentSessions: () => api.get("/analytics/recent-sessions"),
  scoreHistory: (days = 30) => api.get(`/analytics/score-history?days=${days}`),
};

// ── Public Share ────────────────────────────────────────────────────────────
export const shareApi = {
  get: (token: string) => axios.get(`${API_URL}/share/${token}`), // no auth
};
